# Jamaster Workspace

React 19, Vite 8, TypeScript, Tailwind CSS 4 ve shadcn/ui ile Jamaster LMS çalışma alanı.

İlk tasarımdaki beyaz yüzeyler, pastel çevre zemini, kıvrımlı sayfa sekmeleri ve sade tipografi korunur. shadcn/Radix; dialog, menü, seçici, sekme, form, tablo ve sidebar davranışlarını sağlar. Görsel düzen tema tokenları ve uygulamaya ait CSS ile tanımlanır.

## Bu güncelleme

8 Eylül kapsamlı ürün arayüzü incelemesi, düzeltmeler ve açık cihaz/API kabul işleri `docs/production-ui-review.md` içindedir. Uzun formların zorunlu/isteğe bağlı ayrımı ve Jamaster-web karşılaştırması `docs/form-flow-review.md` içindedir. Önceki görsel kararlar `docs/design-review.md` içinde korunur.

- React Router ile `/admin/...` adresleri kullanılır. Hosting yapılandırmasında `single-page-application` geri dönüşü vardır; sayfa adresinden doğrudan açma ve yenileme desteklenir. Tek dosya HTML, `file://` altında MemoryRouter kullanır.
- Çalışma sekmeleri Genel grubuyla açılır; ziyaret edilen sayfalar eklenir, tekrar ziyaretlerde aynı sekme kullanılır. Sekmeler kapanabilir, daralabilir ve listeden seçilebilir. Kapatma düğmesi hover veya klavye odağında sağ üstte görünür; dokunmatik cihazlarda görünür kalır. Sayfa durumu ve filtreler şube/sayfa anahtarıyla `sessionStorage` içinde saklanır; sayfa ağacı arka planda açık tutulmaz.
- Sidebar kapalı ve açık durumda tek, kesintisiz bir cam paneldir. Dar menü ve tam menü aynı bağlantı elemanlarını kullanır; odak yeniden oluşturulmaz. Sağ araç alanı kapanabilir; mobilde Günlük akış ve JamAI alt çubuktan shadcn Drawer ile açılır.
- Tema kullanıcının verdiği ilk `Jamaster-Prototip.html` dosyasındaki renkleri kullanır: `#ffdb39` sarı vurgu, `#48424e` yazı, `#5b5062` erik tonu ve `#0da992` mint. Ölçek seçenekleri %85, %90, %100, %110, %125 ve %150’dir; rem ölçüleri portal içeriğini de kapsar. Mobil ölçek okunabilirlik için %100’dür.
- Ek dialog, input ve select sarmalayıcıları kaldırıldı. Özelleştirilmiş shadcn Dialog, Dropdown Menu, Popover, Select, Input, Navigation Menu, Drawer ve Data Table bileşenleri kullanılır. Avatar/Badge/Progress de shadcn tabanlıdır. İş alanına ait kişi satırı ve başlık kompozisyonları ortak kalır.
- Tablo sütun menüsü birden çok seçime açıktır; mobil kartlarda toplu seçim ve sıralama kullanılır. Tarih aralığı filtresi seçimi açıkça gösterir, arama alanı tek düğmeyle temizlenebilir.
- Öğrenci, grup, öğretmen, gider, finans ve mesaj listelerinde shadcn Table/TanStack Table üzerinden sayfalama ve sütun görünürlüğü bulunur. Masaüstü tablo mobilde kartlara dönüşür. Öğrencilerde çoklu seçim ve CSV çıktısı vardır.
- Kayıt, grup, öğretmen, gider, fiyatlandırma ve iletişim alanları jamaster-web kaynaklarıyla karşılaştırıldı. Kaynak eşleştirmesi `docs/source-comparison.md` içinde tutulur.

- Kayıt ve profil düzenleme ortak alan/model kullanır. Tam önizleme, bölüm düzenleme, alan içi hata, doğum tarihi ve telefon kontrolü bulunur. Telefonlar ülke koduyla saklanır; mevcut maskeli telefon değişmeden korunabilir.
- Kampanya ayrıntıları, satışta yöntem indirimi ve taksit kuruş dağılımı aynı özet içinde kontrol edilir. Günlük araçlar ve takvim güncel tarihle çalışır; çakışan etkinlikler ayrı sütunlara yerleşir.

## Çalıştırma

Node.js 22.18 veya üzeri:

```sh
npm ci
npm run dev
```

```sh
npm run build
npm test
npm run check:pages
npm run preview
```

`check:pages` 113 menü hedefini, öğrenci alt sayfalarını, uygulama kabuğunu ve görüşme kompozisyonunu React ile statik olarak render eder; JamAI ödeme özetinin kayıt değişikliklerini yansıttığını kontrol eder. Tarayıcı veya görsel test değildir. `npm test` 33 senaryoda telefon normalizasyonu, mükerrer kayıt, maskeli eski numara, kayıt/düzenleme, tarih, takvim çakışması, kampanya ve kuruş dağılımı dahil iş kurallarını kontrol eder. Kayıt adımları, önizleme kapsamı, bağlı etiketler ve editör de ayrı render edilir.

## Proje düzeni

| Konum                         | Sorumluluk                                                                                               |
| ----------------------------- | -------------------------------------------------------------------------------------------------------- |
| `src/app`                     | Uygulama kabuğu, yönlendirme, çalışma sekmeleri, görünüm tercihleri, ortak state/reducer                 |
| `src/components/ui`           | Resmî shadcn/ui bileşenleri                                                                              |
| `src/components/layout`       | Sidebar, üst çubuk, sayfa sekmeleri, günlük akış                                                         |
| `src/components/shared`       | Kişi satırı, bölüm başlığı, metrikler ve öğrenci seçimi                                                  |
| `src/features/dashboard`      | İlk tasarımın özet kartları, grafik ve akış bileşenleri                                                  |
| `src/features/students`       | Arama, filtreleme, kayıt adımları, öğrenci profili                                                       |
| `src/features/education`      | Grup listesi/detayı/atama, öğretmen kadrosu/programı, eğitimler, dönemler, müfredat                      |
| `src/features/calendar`       | Haftalık/günlük program, filtreler ve yoklama                                                            |
| `src/features/meetings`       | Görüşme gündemi, geçmiş, kayıt formu ve iş kuralları                                                     |
| `src/features/finance`        | Giderler, fiyat paketleri, satış, tahsilat, abonelik ve analiz sayfaları                                 |
| `src/features/communications` | Kanala göre mesajlar, şablonlar, alıcı ve içerik düzenleme                                               |
| `src/features/administration` | Ekip/şube, doğrulama, otomasyon, sözleşme, dosya, duyuru ve destek                                       |
| `src/features/settings`       | Her ayar kategorisine özel alanlar                                                                       |
| `src/features/insights`       | Rapor kataloğu, dağılımlar, eğitim raporu filtreleri                                                     |
| `src/features/operations`     | Tipli alan modelleri, güncelleme reducer’ı ve kayıt sağlayıcısı                                          |
| `src/features/jamai`          | Yerel öğrenci/gündem özetleri                                                                            |
| `src/styles`                  | Tema; temel bileşen, kabuk, sidebar, çalışma sekmeleri, sağ araçlar, dashboard, dialog ve sayfa stilleri |
| `src/data`                    | jamaster-web menü envanteri ve başlangıç kayıtları                                                       |
| `scripts`                     | Statik sayfa kontrolü ve paylaşılabilir dosya üretimi                                                    |

Genel `ModulePage` kaldırıldı. Alan sayfaları kendi bileşenleri ve işlemleriyle yönlendirilir. Ortak bileşenler görsel tutarlılığı sağlar.

## Görsel düzen ve etkileşimler

- Sayfa içi gezinme, başlık ve açıklamanın altında bireysel pill bağlantılar kullanır. Öğrenci durumlarının sayıları kayıtlardan hesaplanır.
- Cam efekti sidebar, pasif çalışma sekmeleri ve küçük gezinme kontrollerindedir. Beyaz veri yüzeyleri ve dialog içerikleri opaktır. Desteklemeyen tarayıcılarda ve azaltılmış saydamlık tercihinde opak alternatif kullanılır.

- Sidebar varsayılan dar görünür. Fareyle üzerine gelince içerik üzerine genişler; ana içerik genişliği değişmez. Dokunmatik ekranlarda düğmeyle açılır; mobilde shadcn Sheet kullanılır. Klavye ile odaklanınca da genişler.
- Sidebar’ın masaüstünde kaybolmasına neden olan eski global `.hidden { display:none!important }` kuralı kaldırıldı. Tailwind’in duyarlı görünürlük sınıfları korunur.
- Altı grup, 31 ana menü ve 113 hedef jamaster-web envanterinden korunur.
- Ortalanmış dialoglar 150 ms giriş, 120 ms çıkış animasyonu ve opaklık kullanan arka katmanla açılır. Blur kullanılmaz. Escape/odak tuzağı Radix tarafından sağlanır; azaltılmış hareket tercihi desteklenir.
- Günlük akış ve JamAI aynı yuvarlatılmış panelin iç başlığındaki küçük geçiş kontrolünü kullanır; dış sekmeler kaldırılmıştır. Arama logonun altında ve ⌘K/Ctrl+K ile açılır.
- Grup kapasitesi kontrol edilir; öğrenci ataması öğrenci kaydına yansır. Grup düzenlemesi ilgili öğrencileri günceller. Öğretmen adı değişince grup, öğrenci ve takvim bilgileri güncellenir.
- Görüşme formunda eksik sonuç ve tarih alanında hata ve odak yönlendirmesi vardır; notun karakter sayısı gösterilir. Görüşmeler mevcut doğrulama kurallarıyla geçmişe kaydedilir. Takip tarihi takvime eklenir. SMS taslağında başlık, alıcı ve tam mesaj içeriği korunur.
- Gider, fiyat paketi, satış, ödeme kaydı, mesaj şablonu, ekip bilgileri, duyuru, sözleşme ve otomasyon kuralları düzenlenebilir.
- Dosya ekranı güncel öğrenci/takvim CSV’lerini üretir; 2 MB’a kadar çalışma dosyaları tarayıcıya eklenip indirilebilir. Sözleşme metni ve destek taslakları indirilebilir.

## Entegrasyon sınırı

Bu, işlevsel bir **sunum prototipidir**. Başlangıç kayıtları tasarım içindir. Arayüzde demo etiketi kullanılmaz. Gerçek Jamaster veritabanına, ödeme sağlayıcısına veya mesaj gönderim servisine bağlı değildir; jamaster-web reposuna değişiklik yapılmadı.

Kayıtlar React state ve sürümlenmiş `localStorage` anahtarlarında tutulur. Aynı tarayıcı ve adres içinde yenilemeden sonra korunur; başka cihazlarla eşitlenmez. Tarayıcı depolaması engelliyse oturum içindeki işlemler çalışır. Şube değiştirmek arayüz bağlamını değiştirir; ayrı sunucu verisi veya yetki denetimi yüklemez.

JamAI yerel kurallarla özet üretir; LLM bağlantısı yoktur. Mesajlar taslak olarak saklanır; dışarıya gönderilmez. Otomasyon kuralları düzenlenir; arka planda zamanlanmış görev çalışmaz. Ödeme ekranı yerel kayıt oluşturur, para tahsil etmez. Dosyalar uzak sunucuya yüklenmez. Ekran kilidi kimlik doğrulaması değildir.

Eğitim raporlarında mevcut öğrenci/devam/grup/görüşme alanlarından üretilebilen sorgular çalışır. Bonus, sözleşme bitiş riski, grup transfer geçmişi gibi ek sunucu alanlarına bağlı raporlar veri kaynağı bağlanana kadar boş kalır. Bazı üst düzey grafik ve toplamlar tasarım amaçlı dönem özetleridir. Finans akışında öğrenci başına tek güncel eğitim paketi ve tam bedel ödeme kaydı modellenmiştir; kısmi ödeme muhasebesi ve çoklu satış defteri ayrı bir API entegrasyonu gerektirir.

## Paylaşım

Üretim derlemesinden sonra:

```sh
node scripts/package-deliverables.mjs
```

- `deliverables/Jamaster-Prototip.html`: React uygulaması, CSS, logo, ikonlar ve fontlar gömülü tek dosya. Tarayıcıda doğrudan açılır.
- `deliverables/Jamaster-React-Vite.zip`: Kurulabilir proje kaynakları.

Bu revizyonda denetimli önizleme başlatıldı; tarayıcı erişimi `ERR_BLOCKED_BY_CLIENT` ile engellendi. Kaynak ve statik render incelemesi yapıldı; tarayıcıda görsel inceleme yapılamadı. Görsel/e2e doğrulama ve Safari/Mac cihaz testi tamamlanamadı. Üretim derlemesi, iş kuralları, statik sayfa render’ı ve çevrimdışı dosya bütünlüğü kontrol edildi.

shadcn/ui ve Lucide MIT lisanslıdır. Lisans metinleri proje kökünde bulunur.
