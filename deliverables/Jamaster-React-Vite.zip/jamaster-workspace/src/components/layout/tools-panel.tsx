import { useDisplay } from '@/app/display-provider';
import { Icon } from '@/components/shared/icon';
import { Button } from '@/components/ui/button';
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import { useToolsDrawer } from '@/hooks/use-mobile';
import { DailyPanel } from './daily-panel';
export function ToolsPanel() {
  const display = useDisplay(),
    mobile = useToolsDrawer();
  return (
    <>
      {!mobile && display.toolsOpen && <DailyPanel />}
      <nav className="mobile-tools" aria-label="Günlük araçlar">
        <Button
          variant="ghost"
          aria-haspopup="dialog"
          aria-expanded={display.mobileOpen && display.tool === 'daily'}
          onClick={() => {
            display.setPreview(null);
            display.setTool('daily');
            display.setMobileOpen(true);
          }}
        >
          <Icon name="calendar-days" />
          Günlük akış
        </Button>
        <Button
          variant="ghost"
          aria-haspopup="dialog"
          aria-expanded={display.mobileOpen && display.tool === 'jamai'}
          onClick={() => {
            display.setPreview(null);
            display.setTool('jamai');
            display.setMobileOpen(true);
          }}
        >
          <Icon name="sparkles" />
          JamAI
        </Button>
      </nav>
      <Drawer open={mobile && display.mobileOpen} onOpenChange={display.setMobileOpen}>
        <DrawerContent className="tools-drawer">
          <DrawerHeader className="sr-only">
            <DrawerTitle>Çalışma alanı araçları</DrawerTitle>
            <DrawerDescription>Günlük akış ile JamAI arasında geçiş yapın.</DrawerDescription>
          </DrawerHeader>
          <DailyPanel mobile />
        </DrawerContent>
      </Drawer>
    </>
  );
}
