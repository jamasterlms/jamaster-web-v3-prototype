import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Button } from '@/components/ui/button';
import { Icon } from '@/components/shared/icon';
const selector =
  'input:not([type=hidden]):not([type=file]):not([type=checkbox]):not([type=radio]),textarea,button[role=combobox]';
export function KeyboardToolbar() {
  const [target, setTarget] = useState<HTMLElement | null>(null);
  const [viewport, setViewport] = useState({ top: 0, height: 0, open: false });
  useEffect(() => {
    let baseline = window.innerHeight;
    const rotate = () => {
      baseline = window.innerHeight;
    };
    window.addEventListener('orientationchange', rotate);
    const update = () => {
      const element = document.activeElement as HTMLElement | null;
      const editable = element?.matches(
        'input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=file]),textarea',
      );
      const vv = window.visualViewport;
      baseline = Math.max(baseline, window.innerHeight, vv?.height || 0);
      const open =
        !!editable &&
        !!vv &&
        window.matchMedia('(pointer:coarse)').matches &&
        baseline - vv.height > 120;
      if (editable) setTarget(element!);
      setViewport({ top: vv?.offsetTop || 0, height: vv?.height || window.innerHeight, open });
      document.documentElement.dataset.keyboardOpen = String(open);
      document.documentElement.style.setProperty(
        '--keyboard-toolbar-height',
        open ? '44px' : '0px',
      );
    };
    document.addEventListener('focusin', update);
    document.addEventListener('focusout', update);
    window.visualViewport?.addEventListener('resize', update);
    window.visualViewport?.addEventListener('scroll', update);
    return () => {
      window.removeEventListener('orientationchange', rotate);
      document.removeEventListener('focusin', update);
      document.removeEventListener('focusout', update);
      window.visualViewport?.removeEventListener('resize', update);
      window.visualViewport?.removeEventListener('scroll', update);
      delete document.documentElement.dataset.keyboardOpen;
      document.documentElement.style.removeProperty('--keyboard-toolbar-height');
    };
  }, []);
  const scope = target ? target.closest('form,[role=dialog]') || target.ownerDocument : null;
  const inputs =
    target && scope
      ? Array.from(scope.querySelectorAll<HTMLElement>(selector)).filter(
          (e) => !e.matches(':disabled,[readonly]') && e.getClientRects().length > 0,
        )
      : [];
  const index = target ? inputs.indexOf(target) : -1;
  const move = (step: number) => {
    const next = inputs[index + step];
    next?.focus({ preventScroll: true });
    next?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  };
  if (!viewport.open) return null;
  return createPortal(
    <div
      className="keyboard-toolbar"
      role="toolbar"
      aria-label="Form alanları"
      style={{ top: viewport.top + viewport.height - 44 }}
      onPointerDown={(e) => e.preventDefault()}
    >
      <Button
        type="button"
        variant="ghost"
        aria-label="Önceki alan"
        disabled={index <= 0}
        onClick={() => move(-1)}
      >
        <Icon name="chevron-up" />
        Geri
      </Button>
      <Button
        type="button"
        variant="ghost"
        aria-label="Sonraki alan"
        disabled={index < 0 || index >= inputs.length - 1}
        onClick={() => move(1)}
      >
        İleri
        <Icon name="chevron-down" />
      </Button>
      <Button type="button" variant="ghost" onClick={() => target?.blur()}>
        <Icon name="keyboard" />
        Klavyeyi kapat
      </Button>
    </div>,
    document.body,
  );
}
