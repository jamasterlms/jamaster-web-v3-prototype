import { parsePhoneNumberFromString } from 'libphonenumber-js/max';
import { useId, type ComponentProps } from 'react';
import { BaseInput } from './base-input';
/** Keeps the complete number editable: pasted +country codes and national numbers are accepted. */
export function PhoneInput(props: ComponentProps<'input'>) {
  const id = useId();
  const value = String(props.value ?? '');
  const number = parsePhoneNumberFromString(value, { defaultCountry: 'TR', extract: false });
  const country = number?.country || (value.startsWith('+') ? 'INT' : 'TR');
  return (
    <div className="phone-control">
      <div className="phone-input-wrap">
        <span className="phone-country" aria-hidden="true">
          {country}
          <small>{number ? `+${number.countryCallingCode}` : country === 'TR' ? '+90' : '+'}</small>
        </span>
        <BaseInput
          {...props}
          type="tel"
          inputMode="tel"
          autoComplete={props.autoComplete || 'tel'}
          aria-describedby={[props['aria-describedby'], id].filter(Boolean).join(' ')}
          placeholder={props.placeholder || '05xx xxx xx xx'}
        />
      </div>
      <span className="phone-format-hint" id={id}>
        {number?.isValid()
          ? number.formatInternational()
          : 'Ülke koduyla veya Türkiye için 0 ile başlayan numaranızı girin.'}
      </span>
    </div>
  );
}
