import type { ComponentProps } from 'react';
import { BaseInput } from './base-input';
import { PhoneInput } from './phone-input';
export function Input(props: ComponentProps<'input'>) {
  return props.type === 'tel' ? <PhoneInput {...props} /> : <BaseInput {...props} />;
}
