import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
} from '@/components/ui/navigation-menu';
import { Link, useLocation } from 'react-router-dom';
export function PageNavigation({
  items,
}: {
  items: { to: string; label: string; count?: number }[];
}) {
  const { pathname, search } = useLocation();
  return (
    <NavigationMenu viewport={false} className="page-navigation" aria-label="Alt sayfalar">
      <NavigationMenuList>
        {items.map((item) => {
          const hasQuerySibling = items.some((v) => v.to.startsWith(pathname + '?'));
          const active =
            (item.to.includes('?') || hasQuerySibling ? pathname + search : pathname) === item.to;
          return (
            <NavigationMenuItem key={item.to}>
              <NavigationMenuLink active={active} asChild>
                <Link to={item.to} aria-current={active ? 'page' : undefined}>
                  <span>{item.label}</span>
                  {item.count !== undefined && (
                    <span className="page-navigation-count">{item.count}</span>
                  )}
                </Link>
              </NavigationMenuLink>
            </NavigationMenuItem>
          );
        })}
      </NavigationMenuList>
    </NavigationMenu>
  );
}
