import { ErrorBoundary } from '@/app/error-boundary';
import { App } from '@/app/app';
import { DisplayProvider } from '@/app/display-provider';
import { NavigationProvider } from '@/app/navigation/navigation-provider';
import { WorkspaceProvider } from '@/app/workspace-provider';
import { OperationsProvider } from '@/features/operations/operations-provider';
import { NavigationBridge } from '@/hooks/use-route';
import '@/styles/theme.css';
import '@/styles/base.css';
import '@/styles/layout.css';
import '@/styles/sidebar.css';
import '@/styles/working-tabs.css';
import '@/styles/tools.css';
import '@/styles/dashboard.css';
import '@/styles/pages.css';
import '@/styles/dialogs.css';
import '@/styles/refinements.css';
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, MemoryRouter } from 'react-router-dom';
const Router = window.location.protocol === 'file:' ? MemoryRouter : BrowserRouter;
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <Router>
        <NavigationBridge />
        <NavigationProvider>
          <OperationsProvider>
            <WorkspaceProvider>
              <DisplayProvider>
                <App />
              </DisplayProvider>
            </WorkspaceProvider>
          </OperationsProvider>
        </NavigationProvider>
      </Router>
    </ErrorBoundary>
  </StrictMode>,
);
