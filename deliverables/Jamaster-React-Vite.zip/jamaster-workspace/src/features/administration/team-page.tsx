import { DialogFooter } from '@/components/ui/dialog';
import { useWorkspace } from '@/app/workspace-provider';
import { SearchField } from '@/components/shared/feature-primitives';
import { Icon } from '@/components/shared/icon';
import { Avatar, PageHeading, StatusBadge } from '@/components/shared/primitives';
import { Button } from '@/components/ui/button';
import { DataTable } from '@/components/ui/data-table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { MultiSelect } from '@/components/ui/multi-select';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { operationalData } from '@/data/institution';
import { identifyTeamRows } from '@/features/entities/entity-model';
import { useEntityNavigation } from '@/features/entities/use-entity-navigation';
import { usePageState } from '@/hooks/use-page-state';
import { navigate } from '@/hooks/use-route';
import { normalize } from '@/lib/format';
import { emailSchema, localDate, optionalPhoneSchema, normalizePhone } from '@/lib/validation';
import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { toast } from 'sonner';
type Draft = {
  id: string;
  name: string;
  role: string;
  contact: string;
  status: string;
  phone: string;
  email: string;
};
export function TeamPage({ route }: { route: string }) {
  const { state, dispatch } = useWorkspace(),
    openEntity = useEntityNavigation(),
    [params] = useSearchParams();
  const key = route.split('/')[1],
    branch = key === 'branches',
    users = key === 'users',
    create = route.endsWith('/form'),
    base = `/${route.split('/').slice(0, 2).join('/')}`;
  const data = operationalData[key],
    rows = identifyTeamRows(state.moduleRows[key] || data.rows, key);
  const detailId =
    !create && !branch && route.split('/').length === 3 && !route.endsWith('/salary')
      ? decodeURIComponent(route.split('/').at(-1)!)
      : undefined;
  const selected = rows.find((r) => r[5] === detailId);
  const blank = (): Draft => ({
    id: '',
    name: '',
    role: branch ? '' : 'Eğitim danışmanı',
    contact: !branch && !users ? state.branch : '',
    status: 'Aktif',
    phone: '',
    email: '',
  });
  const draftFor = (r: string[]): Draft => ({
    id: r[5],
    name: r[0],
    role: r[users ? 2 : 1],
    contact: r[branch ? 3 : users ? 1 : 2],
    status: r[4],
    phone: r[6] || '',
    email: r[7] || '',
  });
  const [editing, setEditing] = useState<Draft | null>(
    create ? blank() : selected && params.has('edit') ? draftFor(selected) : null,
  );
  const [query, setQuery] = usePageState('query', ''),
    [statuses, setStatuses] = usePageState<string[]>('statuses', []),
    [roles, setRoles] = usePageState<string[]>('roles', []);
  const close = () => {
    setEditing(null);
    if (create) navigate(base);
  };
  const edit = (r: string[]) => setEditing(draftFor(r));
  const open = (r: string[], full = false) =>
    openEntity({ kind: users ? 'users' : 'staff', id: r[5] }, full);
  const roleOptions = ['Şube yöneticisi', 'Eğitim danışmanı', 'Öğrenci işleri', 'Öğretmen'];
  const field = (key: keyof Draft, label: string, type = 'text', required = false) => (
    <div className="form-field">
      <Label htmlFor={`team-${key}`}>
        {label}
        {required ? ' *' : ''}
      </Label>
      <Input
        id={`team-${key}`}
        type={type}
        required={required}
        value={editing?.[key] || ''}
        placeholder={`${label} girin`}
        onChange={(e) => setEditing((v) => (v ? { ...v, [key]: e.target.value } : v))}
      />
    </div>
  );
  return (
    <>
      {detailId ? (
        <section className="entity-detail-page">
          <Button variant="ghost" asChild>
            <Link to={base}>← Listeye dön</Link>
          </Button>
          <PageHeading
            title={selected?.[0] || 'Kayıt bulunamadı'}
            description="Personel bilgileri ve çalışma alanı."
          />
          {selected && (
            <>
              <div className="detail-header">
                <Avatar name={selected[0]} />
                <StatusBadge>{selected[4]}</StatusBadge>
              </div>
              <div className="detail-grid">
                {[
                  ['Görev', selected[users ? 2 : 1]],
                  ['Şube / iletişim', selected[users ? 1 : 2]],
                  ['Kayıt / son giriş', selected[3]],
                  ['Telefon', selected[6]],
                  ['E-posta', selected[7]],
                ].map(([label, value]) => (
                  <div key={label}>
                    <small>{label}</small>
                    <b>{value || 'Belirtilmedi'}</b>
                  </div>
                ))}
              </div>
              <div className="form-actions">
                {selected[6] && (
                  <Button variant="outline" asChild>
                    <a href={`tel:${selected[6]}`}>Ara</a>
                  </Button>
                )}
                <Button onClick={() => edit(selected)}>
                  <Icon name="pencil" />
                  Bilgileri düzenle
                </Button>
              </div>
            </>
          )}
        </section>
      ) : (
        <>
          <PageHeading
            title={data.title}
            description={
              branch
                ? 'Şubelerinizi ve sorumlu ekiplerinizi yönetin.'
                : 'Ekibinizin görevleri, iletişim bilgileri ve çalışma alanları.'
            }
          >
            <Button onClick={() => setEditing(blank())}>
              <Icon name="plus" />
              {data.create}
            </Button>
          </PageHeading>
          <div className="module-toolbar">
            <SearchField
              value={query}
              onChange={setQuery}
              placeholder={branch ? 'Şube veya şehir ara' : 'Ad, görev veya iletişim bilgisi ara'}
            />
          </div>
          <div className="module-toolbar secondary-filters">
            <MultiSelect
              label="Durum"
              value={statuses}
              onChange={setStatuses}
              options={['Aktif', 'Pasif', 'İzinli'].map((value) => ({ value, label: value }))}
            />
            <MultiSelect
              label={branch ? 'Şehir' : 'Görev'}
              value={roles}
              onChange={setRoles}
              options={[...new Set(rows.map((r) => r[users ? 2 : 1]))].map((value) => ({
                value,
                label: value,
              }))}
            />
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setQuery('');
                setStatuses([]);
                setRoles([]);
              }}
            >
              Sıfırla
            </Button>
          </div>
          <DataTable
            data={rows.filter(
              (r) =>
                normalize([...r.slice(0, 5), ...r.slice(6, 8)].join(' ')).includes(
                  normalize(query),
                ) &&
                (!statuses.length || statuses.includes(r[4])) &&
                (!roles.length || roles.includes(r[users ? 2 : 1])),
            )}
            getRowId={(r) => r[5]}
            onOpen={branch ? undefined : open}
            columns={[
              {
                id: 'name',
                header: branch ? 'Şube' : 'Ad soyad',
                accessorFn: (r) => r[0],
                cell: ({ row }) =>
                  branch ? (
                    row.original[0]
                  ) : (
                    <Link to={`${base}/${row.original[5]}`}>{row.original[0]}</Link>
                  ),
              },
              {
                id: 'role',
                header: branch ? 'Şehir' : 'Görev',
                accessorFn: (r) => r[users ? 2 : 1],
              },
              {
                id: 'contact',
                header: branch ? 'Yetkili' : users ? 'E-posta' : 'Şube',
                accessorFn: (r) => r[branch ? 3 : users ? 1 : 2],
              },
              {
                id: 'status',
                header: 'Durum',
                accessorFn: (r) => r[4],
                cell: ({ row }) => <StatusBadge>{row.original[4]}</StatusBadge>,
              },
              {
                id: 'actions',
                header: 'İşlemler',
                cell: ({ row }) => (
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm" onClick={() => edit(row.original)}>
                      Düzenle
                    </Button>
                    {branch && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          dispatch({ type: 'branch/set', branch: row.original[0] });
                          navigate('admin/dashboard');
                        }}
                      >
                        Şubeye geç
                      </Button>
                    )}
                  </div>
                ),
              },
            ]}
            mobileCard={(r) => (
              <>
                <div className="card-person">
                  <Avatar name={r[0]} />
                  <strong>{r[0]}</strong>
                </div>
                <p>{r[users ? 2 : 1]}</p>
                <StatusBadge>{r[4]}</StatusBadge>
                <div className="form-actions">
                  <Button variant="outline" onClick={() => edit(r)}>
                    Düzenle
                  </Button>
                  {!branch && (
                    <Button variant="ghost" onClick={(e) => open(r, e.detail > 1)}>
                      Profili aç
                    </Button>
                  )}
                </div>
              </>
            )}
          />
        </>
      )}
      <Dialog
        open={!!editing}
        onOpenChange={(v) => {
          if (!v) close();
        }}
      >
        <DialogContent preventOutsideClose className="jam-modal dialog-wide">
          <DialogHeader>
            <DialogTitle>{editing?.id ? 'Bilgileri düzenle' : data.create}</DialogTitle>
            <DialogDescription>
              Önce zorunlu bilgileri tamamlayın; ek iletişim bilgilerini daha sonra
              ekleyebilirsiniz.
            </DialogDescription>
          </DialogHeader>
          {editing && (
            <form
              className="dialog-form"
              onSubmit={(e) => {
                e.preventDefault();
                const draft = {
                  ...editing,
                  name: editing.name.trim(),
                  contact: editing.contact.trim(),
                  phone: normalizePhone(editing.phone),
                  email: editing.email.trim().toLowerCase(),
                };
                if (draft.name.length < 2 || !draft.role.trim() || !draft.contact) {
                  toast.error('Zorunlu alanları tamamlayın.');
                  return;
                }
                if (
                  (users && !emailSchema.safeParse(draft.contact).success) ||
                  (draft.email && !emailSchema.safeParse(draft.email).success) ||
                  !optionalPhoneSchema.safeParse(draft.phone).success
                ) {
                  toast.error('Telefon ve e-posta bilgilerini kontrol edin.');
                  return;
                }
                if (
                  rows.some(
                    (r) =>
                      r[5] !== draft.id &&
                      (normalize(r[0]) === normalize(draft.name) ||
                        (users && normalize(r[1]) === normalize(draft.contact)) ||
                        (draft.phone && normalizePhone(r[6] || '') === draft.phone)),
                  )
                ) {
                  toast.error('Bu bilgilerle bir kayıt zaten var.');
                  return;
                }
                const old = rows.find((r) => r[5] === draft.id);
                const record = branch
                  ? [draft.name, draft.role, old?.[2] || '0', draft.contact, draft.status]
                  : users
                    ? [
                        draft.name,
                        draft.contact.toLowerCase(),
                        draft.role,
                        old?.[3] || 'Henüz giriş yapmadı',
                        draft.status,
                      ]
                    : [
                        draft.name,
                        draft.role,
                        draft.contact,
                        old?.[3] || localDate(),
                        draft.status,
                      ];
                record.push(draft.id || crypto.randomUUID(), draft.phone, draft.email);
                if (old?.[8]) record[8] = old[8];
                dispatch({
                  type: 'module/rows',
                  key,
                  rows: old ? rows.map((r) => (r[5] === draft.id ? record : r)) : [record, ...rows],
                });
                toast.success('Bilgiler kaydedildi.');
                close();
              }}
            >
              <div className="dialog-form-body">
                <fieldset className="form-section" data-form-section="required">
                  <legend>
                    Temel bilgiler <span>Zorunlu</span>
                  </legend>
                  <div className="form-grid">
                    {field('name', branch ? 'Şube adı' : 'Ad soyad', 'text', true)}
                    {branch ? (
                      field('role', 'Şehir', 'text', true)
                    ) : (
                      <div className="form-field">
                        <Label htmlFor="team-role">Görev *</Label>
                        <Select
                          value={editing.role}
                          onValueChange={(role) => setEditing({ ...editing, role })}
                        >
                          <SelectTrigger id="team-role">
                            <SelectValue placeholder="Görev seçin" />
                          </SelectTrigger>
                          <SelectContent>
                            {[...new Set([...roleOptions, editing.role])]
                              .filter(Boolean)
                              .map((v) => (
                                <SelectItem key={v} value={v}>
                                  {v}
                                </SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                    {field(
                      'contact',
                      branch ? 'Şube yetkilisi' : users ? 'E-posta' : 'Şube',
                      users ? 'email' : 'text',
                      true,
                    )}
                    <div className="form-field">
                      <Label htmlFor="team-status">Durum *</Label>
                      <Select
                        value={editing.status}
                        onValueChange={(status) => setEditing({ ...editing, status })}
                      >
                        <SelectTrigger id="team-status">
                          <SelectValue placeholder="Durum seçin" />
                        </SelectTrigger>
                        <SelectContent>
                          {['Aktif', 'Pasif', 'İzinli'].map((v) => (
                            <SelectItem key={v} value={v}>
                              {v}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </fieldset>
                <fieldset
                  className="form-section form-section-optional"
                  data-form-section="optional"
                >
                  <legend>
                    İletişim <span>İsteğe bağlı</span>
                  </legend>
                  <div className="form-grid">
                    {field('phone', 'Telefon', 'tel')}
                    {!users && field('email', 'E-posta', 'email')}
                  </div>
                </fieldset>
              </div>
              <DialogFooter className="form-actions">
                <Button type="button" variant="outline" onClick={close}>
                  Vazgeç
                </Button>
                <Button type="submit">Kaydet</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
