import { useWorkspace } from '@/app/workspace-provider';
import { PageNavigation } from '@/components/navigation/page-navigation';
import { PageHeading } from '@/components/shared/primitives';
import { Button } from '@/components/ui/button';
import { createMeeting } from '@/features/meetings/meeting-model';
import { usePageState } from '@/hooks/use-page-state';
import { navigate } from '@/hooks/use-route';
import { useRef } from 'react';
import { toast } from 'sonner';
import { emptyRegistration, type RegistrationDraft } from './registration-model';
import { RegistrationFields, registrationStepFields } from './registration-fields';
import { RegistrationReview } from './registration-review';
import { studentFromDraft } from './student-model';
import { useRegistrationValidation } from './use-registration-validation';

export function RegistrationPage() {
  const { state, dispatch } = useWorkspace();
  const [savedStep, setStep] = usePageState('registration-step', 0);
  const [savedDraft, setDraft] = usePageState<RegistrationDraft>(
    'registration-draft',
    emptyRegistration,
  );
  const draft = { ...emptyRegistration, ...savedDraft };
  const step = Number.isInteger(savedStep) ? Math.max(0, Math.min(3, savedStep)) : 0;
  const [visited, setVisited] = usePageState('registration-visited', step);
  const validation = useRegistrationValidation(draft, state.students);
  const committed = useRef(false);
  const patch = (value: Partial<RegistrationDraft>) =>
    setDraft((previous) => ({ ...emptyRegistration, ...previous, ...value }));
  const move = (next: number) => {
    setStep(next);
    setVisited((current) => Math.max(current, next));
    requestAnimationFrame(() => document.getElementById('registration-step-title')?.focus());
  };
  const submit = () => {
    if (committed.current) return;
    const errors = validation.validate(step === 3 ? undefined : registrationStepFields[step]);
    if (Object.keys(errors).length) {
      const invalidStep = registrationStepFields.findIndex((keys) =>
        keys.some((key) => errors[key]),
      );
      if (step === 3) setStep(Math.max(0, invalidStep));
      validation.focusError();
      return;
    }
    if (step < 3) {
      move(step + 1);
      return;
    }
    const parsed = validation.parse();
    if (!parsed.success) return;
    committed.current = true;
    const data = parsed.data;
    const id = Math.max(0, ...state.students.map((s) => s.id)) + 1;
    dispatch({ type: 'student/save', student: studentFromDraft(data, id) });
    dispatch({
      type: 'meeting/save',
      ...createMeeting(
        {
          studentId: id,
          type: data.meetingType,
          score: data.meetingScore,
          result: data.meetingResult,
          date: data.meetingDate,
          reason: data.negativeReason,
          note: data.meetingNote,
        },
        data.name,
      ),
    });
    setDraft({ ...emptyRegistration });
    setStep(0);
    setVisited(0);
    toast.success('Öğrenci kaydı oluşturuldu.');
    navigate(data.meetingResult === 'SALE' ? `admin/sales/${id}` : `admin/students/${id}`);
  };
  const titles = ['Kişisel bilgiler', 'Eğitim bilgileri', 'Görüşme sonucu', 'Önizleme'];
  const parsed = step === 3 ? validation.parse() : undefined;
  return (
    <>
      <PageHeading
        title="Yeni öğrenci kaydı"
        description="Kişisel bilgiler, eğitim tercihleri ve ilk görüşme tek bir akışta."
      />
      <PageNavigation
        items={[
          { to: '/admin/students', label: 'Aktif öğrenciler' },
          { to: '/admin/students/past', label: 'Geçmiş öğrenciler' },
          { to: '/admin/students/potential', label: 'Potansiyel' },
          { to: '/admin/students/register', label: 'Kayıt oluştur' },
        ]}
      />
      <ol className="registration-steps" aria-label="Kayıt adımları">
        {titles.map((title, index) => (
          <li key={title} aria-current={step === index ? 'step' : undefined}>
            <Button
              type="button"
              variant={step === index ? 'default' : 'ghost'}
              disabled={index > Math.max(step, visited)}
              onClick={() => move(index)}
            >
              {index + 1}
              <span>{title}</span>
            </Button>
          </li>
        ))}
      </ol>
      <form
        noValidate
        ref={validation.formRef}
        className="dialog-form module-form registration-form"
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        <div className="form-section-heading">
          <div>
            <span className="eyebrow">ADIM {step + 1} / 4</span>
            <h2 id="registration-step-title" tabIndex={-1}>
              {titles[step]}
            </h2>
          </div>
          <p>
            {step === 3
              ? 'Kaydetmeden önce bilgileri kontrol edin.'
              : '* işaretli alanlar zorunludur.'}
          </p>
        </div>
        {Object.values(validation.errors).some(Boolean) && (
          <div className="form-error-summary" role="alert">
            İşaretli alanları kontrol edin. Bilgileriniz korunuyor.
          </div>
        )}
        {step < 3 ? (
          <RegistrationFields
            section={step}
            draft={draft}
            patch={patch}
            errors={validation.errors}
            validateField={validation.validateField}
          />
        ) : (
          <RegistrationReview draft={parsed?.success ? parsed.data : draft} onEdit={move} />
        )}
        <div className="form-actions registration-actions">
          {step > 0 && (
            <Button type="button" variant="outline" onClick={() => move(step - 1)}>
              Geri
            </Button>
          )}
          <Button type="submit">{step === 3 ? 'Bilgileri onayla ve kaydet' : 'Devam et'}</Button>
        </div>
      </form>
    </>
  );
}
