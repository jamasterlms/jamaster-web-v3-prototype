import { useWorkspace } from '@/app/workspace-provider';
import { PageNavigation } from '@/components/navigation/page-navigation';
import { PageHeading } from '@/components/shared/primitives';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { labelFor, meetingResults, meetingTypes } from '@/features/meetings/meeting-options';
import { Link } from 'react-router-dom';
import { RegistrationReview } from './registration-review';
import { StudentDetail } from './student-dialogs';
import { studentDraft } from './student-model';
import { StudentRecords } from './student-records';
export function StudentPage({ id, section = 'overview' }: { id: number; section?: string }) {
  const { state } = useWorkspace(),
    student = state.students.find((s) => s.id === id);
  if (!student)
    return (
      <>
        <PageHeading title="Öğrenci bulunamadı" />
        <Button asChild>
          <Link to="/admin/students">Öğrencilere dön</Link>
        </Button>
      </>
    );
  return (
    <>
      <PageHeading
        title={student.name}
        description={`Öğrenci no: ${id} · Danışman: ${student.advisor || 'Atanmadı'}`}
      />
      <PageNavigation
        items={[
          { to: `/admin/students/${id}`, label: 'Öğrenci bilgileri' },
          { to: `/admin/students/${id}/payments`, label: 'Satış ve tahsilatlar' },
          { to: `/admin/students/${id}/polling-history`, label: 'Yoklama geçmişi' },
          { to: `/admin/students/${id}/history`, label: 'Görüşme geçmişi' },
        ]}
      />
      {section === 'payments' || section === 'polling-history' ? (
        <StudentRecords id={id} section={section} />
      ) : (
        <>
          {section === 'overview' && (
            <>
              <Card className="student-profile-card">
                <StudentDetail student={student} />
              </Card>
              {student.profile && (
                <RegistrationReview draft={studentDraft(student)} includeMeeting={false} />
              )}
            </>
          )}
          <h2 className="subsection-title">Görüşme geçmişi</h2>
          {state.meetings
            .filter((m) => m.studentId === id)
            .map((m) => (
              <Card className="meeting-history-card" key={m.id}>
                <div className="flex justify-between">
                  <strong>{labelFor(meetingTypes, m.type)}</strong>
                  <span>{labelFor(meetingResults, m.result)}</span>
                </div>
                <p>{m.note || 'Görüşme notu eklenmedi.'}</p>
                <small>{new Date(m.createdAt).toLocaleString('tr-TR')}</small>
              </Card>
            ))}
          {!state.meetings.some((m) => m.studentId === id) && (
            <p className="empty-inline">Henüz görüşme kaydı bulunmuyor.</p>
          )}
        </>
      )}
    </>
  );
}
