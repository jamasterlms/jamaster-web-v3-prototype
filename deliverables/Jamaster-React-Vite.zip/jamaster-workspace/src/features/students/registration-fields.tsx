import { ProfileImageInput } from '@/components/ui/profile-image-input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import {
  meetingResults,
  meetingTypes,
  negativeReasons,
  scheduledResults,
} from '@/features/meetings/meeting-options';
import { localDate, phoneHint } from '@/lib/validation';
import {
  dayPeriods,
  studentTypes,
  timePeriods,
  type RegistrationDraft,
} from './registration-model';

export const registrationStepFields: (keyof RegistrationDraft)[][] = [
  [
    'studentType',
    'name',
    'email',
    'phone',
    'secondPhone',
    'identityNumber',
    'birthDate',
    'birthPlace',
    'image',
    'address',
    'checkPhone',
  ],
  [
    'courseType',
    'course',
    'level',
    'subLevel',
    'dayPreference',
    'timePreference',
    'customDays',
    'customTime',
    'occupation',
    'source',
    'institution',
    'company',
    'status',
    'advisor',
  ],
  ['meetingType', 'meetingResult', 'meetingScore', 'meetingDate', 'negativeReason', 'meetingNote'],
];
export type RegistrationErrors = Partial<Record<keyof RegistrationDraft, string>>;
export function RegistrationFields({
  section,
  draft,
  patch,
  errors,
  validateField,
  prefix = 'register',
}: {
  section: number;
  draft: RegistrationDraft;
  patch: (value: Partial<RegistrationDraft>) => void;
  errors: RegistrationErrors;
  validateField: (key: keyof RegistrationDraft) => void;
  prefix?: string;
}) {
  const id = (key: keyof RegistrationDraft) => `${prefix}-${key}`;
  const feedback = (key: keyof RegistrationDraft) =>
    errors[key] ? (
      <p className="field-error" id={`${id(key)}-error`}>
        {errors[key]}
      </p>
    ) : null;
  const description = (key: keyof RegistrationDraft) =>
    [
      errors[key] && `${id(key)}-error`,
      (key === 'phone' || key === 'secondPhone') && `${id(key)}-hint`,
    ]
      .filter(Boolean)
      .join(' ') || undefined;
  const field = (key: keyof RegistrationDraft, label: string, type = 'text', required = false) => (
    <div className="form-field" key={key}>
      <Label htmlFor={id(key)}>
        {label}
        {required && <span aria-hidden="true"> *</span>}
      </Label>
      <Input
        id={id(key)}
        name={key}
        type={type}
        placeholder={
          type === 'tel' ? '05xx xxx xx xx' : type === 'email' ? 'ad@kurum.com' : `${label} girin`
        }
        required={required}
        value={String(draft[key] ?? '')}
        aria-invalid={!!errors[key]}
        aria-describedby={description(key)}
        autoComplete={
          (
            {
              name: 'name',
              email: 'email',
              phone: 'tel',
              secondPhone: 'off',
              birthDate: 'bday',
            } as Record<string, string>
          )[key]
        }
        min={key === 'birthDate' ? '1900-01-01' : undefined}
        max={key === 'birthDate' ? localDate() : undefined}
        maxLength={
          key === 'phone' || key === 'secondPhone'
            ? 30
            : key === 'identityNumber'
              ? 30
              : key === 'image'
                ? 2048
                : 160
        }
        onBlur={() => validateField(key)}
        onChange={(e) =>
          patch({ [key]: e.target.value, ...(key === 'phone' ? { checkPhone: false } : {}) })
        }
      />
      {(key === 'phone' || key === 'secondPhone') && (
        <p className="field-hint" id={`${id(key)}-hint`}>
          {phoneHint}
        </p>
      )}
      {feedback(key)}
    </div>
  );
  const select = (
    key: keyof RegistrationDraft,
    label: string,
    options: string[][],
    optional = false,
    disabled = false,
  ) => (
    <div className="form-field" key={key}>
      <Label htmlFor={id(key)}>{label}</Label>
      <Select
        required={label.endsWith('*')}
        value={String(draft[key]) || (optional ? '_unset' : undefined)}
        disabled={disabled}
        onValueChange={(value) => {
          patch({
            [key]: value === '_unset' ? '' : value,
            ...(key === 'level' ? { subLevel: '' } : {}),
            ...(key === 'occupation' ? { institution: '', company: '' } : {}),
            ...(key === 'meetingResult'
              ? { meetingDate: '', negativeReason: '', meetingScore: value === 'NEGATIVE' ? 1 : 3 }
              : {}),
          });
        }}
      >
        <SelectTrigger
          id={id(key)}
          aria-required={label.endsWith('*')}
          aria-invalid={!!errors[key]}
          aria-describedby={description(key)}
          onBlur={() => validateField(key)}
        >
          <SelectValue placeholder="Seçin" />
        </SelectTrigger>
        <SelectContent>
          {optional && <SelectItem value="_unset">Belirtilmedi</SelectItem>}
          {options.map(([value, text]) => (
            <SelectItem key={value} value={value}>
              {text}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {feedback(key)}
    </div>
  );
  const textarea = (key: 'address' | 'meetingNote', label: string, limit: number) => (
    <div className="form-field">
      <Label htmlFor={id(key)}>{label}</Label>
      <Textarea
        id={id(key)}
        name={key}
        placeholder={`${label} yazın…`}
        value={draft[key]}
        maxLength={limit}
        aria-invalid={!!errors[key]}
        aria-describedby={errors[key] ? `${id(key)}-error` : undefined}
        onBlur={() => validateField(key)}
        onChange={(e) => patch({ [key]: e.target.value })}
      />
      <span className="field-hint field-counter">
        {draft[key].length} / {limit}
      </span>
      {feedback(key)}
    </div>
  );
  if (section === 0)
    return (
      <>
        <fieldset className="form-section" data-form-section="required">
          <legend>
            Temel bilgiler <span>Zorunlu</span>
          </legend>
          <div className="form-grid">
            {field('name', 'Ad soyad', 'text', true)}
            {select('studentType', 'Öğrenci tipi *', studentTypes)}
            {field('phone', 'Telefon', 'tel', true)}
            {field('email', 'E-posta', 'email', true)}
          </div>
        </fieldset>
        <fieldset className="form-section form-section-optional" data-form-section="optional">
          <legend>
            Ek kişisel bilgiler <span>İsteğe bağlı</span>
          </legend>
          <p className="form-section-description">
            Bu alanları boş bırakabilir, öğrenci profilinden daha sonra tamamlayabilirsiniz.
          </p>
          <div className="form-grid">
            {field('secondPhone', 'İkinci telefon', 'tel')}
            {field('identityNumber', 'Kimlik / pasaport numarası')}
            {field('birthDate', 'Doğum tarihi', 'date')}
            {field('birthPlace', 'Doğum yeri')}
            <ProfileImageInput
              id={id('image')}
              value={draft.image}
              onChange={(image) => patch({ image })}
            />
          </div>
          {textarea('address', 'Adres', 1000)}
          <div className="field-checkbox">
            <Checkbox
              id={`${prefix}-check`}
              checked={draft.checkPhone}
              onCheckedChange={(v) => patch({ checkPhone: v === true })}
            />
            <Label htmlFor={`${prefix}-check`}>Telefon numarasını öğrenciyle teyit ettim.</Label>
          </div>
        </fieldset>
      </>
    );
  if (section === 1)
    return (
      <>
        <fieldset className="form-section" data-form-section="required">
          <legend>
            Eğitim tercihleri <span>Zorunlu</span>
          </legend>
          <div className="form-grid">
            {select('courseType', 'Ders tipi *', [
              ['GROUP', 'Grup dersi'],
              ['INDIVIDUAL', 'Bireysel ders'],
            ])}
            {select(
              'course',
              'Eğitim *',
              [
                ...new Set(
                  ['Genel İngilizce', 'IELTS Hazırlık', 'İş İngilizcesi', draft.course].filter(
                    Boolean,
                  ),
                ),
              ].map((v) => [v, v]),
            )}
            {select('dayPreference', 'Gün tercihi *', dayPeriods)}
            {draft.dayPreference === 'CUSTOM' &&
              field('customDays', 'Tercih edilen günler', 'text', true)}
            {select('timePreference', 'Saat tercihi *', timePeriods)}
            {draft.timePreference === 'CUSTOM' &&
              field('customTime', 'Tercih edilen saatler', 'text', true)}
            {field('advisor', 'Danışman', 'text', true)}
          </div>
        </fieldset>
        <fieldset className="form-section form-section-optional" data-form-section="optional">
          <legend>
            Seviye ve diğer bilgiler <span>İsteğe bağlı</span>
          </legend>
          <p className="form-section-description">
            Seviye henüz belirlenmediyse boş bırakabilirsiniz.
          </p>
          <div className="form-grid">
            {select(
              'level',
              'Seviye',
              ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'].map((v) => [v, v]),
              true,
            )}
            {select(
              'subLevel',
              'Alt seviye',
              draft.level ? [1, 2].map((v) => [`${draft.level}.${v}`, `${draft.level}.${v}`]) : [],
              true,
              !draft.level,
            )}
            {field('source', 'Bizi nereden duydunuz?')}
            {select(
              'occupation',
              'Meslek',
              [
                ['STUDENT', 'Öğrenci'],
                ['EMPLOYEE', 'Çalışan'],
                ['UNEMPLOYED', 'Çalışmıyor'],
              ],
              true,
            )}
            {draft.occupation === 'STUDENT' && field('institution', 'Okul / kurum')}
            {draft.occupation === 'EMPLOYEE' && field('company', 'Şirket')}
            {select('status', 'Hesap durumu', [
              ['ACTIVE', 'Aktif'],
              ['INACTIVE', 'Pasif'],
            ])}
          </div>
        </fieldset>
      </>
    );
  return (
    <>
      <fieldset className="form-section" data-form-section="required">
        <legend>
          Görüşme bilgileri <span>Zorunlu</span>
        </legend>
        <div className="form-grid">
          {select('meetingType', 'Görüşme tipi *', meetingTypes)}
          {select('meetingResult', 'Görüşme sonucu *', meetingResults)}
          {scheduledResults.has(draft.meetingResult) &&
            field('meetingDate', 'Planlanan tarih ve saat', 'datetime-local', true)}
          {draft.meetingResult === 'NEGATIVE' &&
            select(
              'negativeReason',
              'Olumsuzluk nedeni *',
              negativeReasons.map((v) => [v, v]),
            )}
          <fieldset className="form-field">
            <legend>Görüşme skoru *</legend>
            <div
              className="score-options"
              role="group"
              aria-label="Görüşme skoru"
              tabIndex={-1}
              aria-invalid={!!errors.meetingScore}
              aria-describedby={errors.meetingScore ? `${id('meetingScore')}-error` : undefined}
            >
              {[1, 2, 3, 4, 5].map((score) => (
                <Button
                  key={score}
                  type="button"
                  variant={draft.meetingScore === score ? 'default' : 'outline'}
                  aria-pressed={draft.meetingScore === score}
                  disabled={draft.meetingResult === 'NEGATIVE' && score !== 1}
                  onClick={() => patch({ meetingScore: score })}
                >
                  {score}
                </Button>
              ))}
            </div>
            {feedback('meetingScore')}
          </fieldset>
        </div>
      </fieldset>
      <fieldset className="form-section form-section-optional" data-form-section="optional">
        <legend>
          Görüşme notu <span>İsteğe bağlı</span>
        </legend>
        {textarea('meetingNote', 'Not', 1500)}
      </fieldset>
    </>
  );
}
