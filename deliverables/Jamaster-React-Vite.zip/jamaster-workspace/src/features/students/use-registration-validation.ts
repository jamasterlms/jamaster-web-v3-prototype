import { parseStudentEdit } from './student-model';
import { useRef, useState } from 'react';
import { contactConflict } from '@/lib/validation';
import type { Student } from '@/types';
import { registrationSchema, type RegistrationDraft } from './registration-model';
import type { RegistrationErrors } from './registration-fields';
export function useRegistrationValidation(
  draft: RegistrationDraft,
  students: Student[],
  excludeId?: number,
  edit = false,
) {
  const [errors, setErrors] = useState<RegistrationErrors>({});
  const formRef = useRef<HTMLFormElement>(null);
  const parse = () =>
    edit
      ? parseStudentEdit(
          draft,
          students.find((s) => s.id === excludeId),
        )
      : registrationSchema.safeParse(draft);
  const collect = () => {
    const parsed = parse(),
      found: RegistrationErrors = {};
    if (!parsed.success)
      for (const issue of parsed.error.issues)
        found[issue.path[0] as keyof RegistrationDraft] ||= issue.message;
    const conflict = contactConflict(students, draft, excludeId);
    if (conflict) {
      if (conflict.email.trim().toLowerCase() === draft.email.trim().toLowerCase())
        found.email = `Bu e-posta ${conflict.name} adına kayıtlı (#${conflict.id}).`;
      else found.phone = `Bu telefon ${conflict.name} adına kayıtlı (#${conflict.id}).`;
    }
    return found;
  };
  const validateField = (key: keyof RegistrationDraft) =>
    setErrors((prev) => ({ ...prev, [key]: collect()[key] }));
  const validate = (keys?: (keyof RegistrationDraft)[]) => {
    const all = collect();
    const found = Object.fromEntries(
      Object.entries(all).filter(([key]) => !keys || keys.includes(key as keyof RegistrationDraft)),
    ) as RegistrationErrors;
    setErrors(found);
    return found;
  };
  const focusError = () =>
    requestAnimationFrame(() =>
      formRef.current?.querySelector<HTMLElement>('[aria-invalid="true"]')?.focus(),
    );
  return { errors, setErrors, formRef, validateField, validate, focusError, parse };
}
