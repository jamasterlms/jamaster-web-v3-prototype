import { useWorkspace } from '@/app/workspace-provider';
import { Metrics } from '@/components/shared/feature-primitives';
import { Button } from '@/components/ui/button';
import { DataTable } from '@/components/ui/data-table';
import { attendanceLabel, attendanceStats } from '@/features/calendar/attendance-model';
import { financeRecords, saleBalance } from '@/features/finance/finance-model';
import { ReceiptDialog } from '@/features/finance/receipt-dialog';
import { dateTR, money } from '@/lib/format';
import { useState } from 'react';

export function StudentRecords({ id, section }: { id: number; section: string }) {
  const { state } = useWorkspace();
  const [payment, setPayment] = useState<string | null>(null);
  const finance = financeRecords(state),
    sales = finance.sales.filter((s) => s.studentId === id),
    receipts = finance.receipts
      .filter((r) => r.studentId === id)
      .sort((a, b) => b.date.localeCompare(a.date));
  const sessions = (state.attendanceSessions || [])
    .filter((s) => s.branch === state.branch && Object.hasOwn(s.marks, id))
    .sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
  const stats = attendanceStats(sessions, id);
  const dateLabel = (date: string) =>
    date ? `${dateTR(date)} ${date.slice(0, 4)}` : 'Belirtilmedi';
  return section === 'payments' ? (
    <>
      <Metrics
        items={[
          { label: 'Satış kaydı', value: sales.length },
          {
            label: 'Tahsil edilen',
            value: money(receipts.reduce((n, r) => n + r.amount, 0)),
            highlight: true,
          },
          {
            label: 'Kalan bakiye',
            value: money(sales.reduce((n, s) => n + saleBalance(s, receipts), 0)),
          },
        ]}
      />
      <h2 className="subsection-title">Satış geçmişi</h2>
      <DataTable
        name="student-sales"
        data={sales}
        getRowId={(s) => s.id}
        columns={[
          { accessorKey: 'course', header: 'Eğitim' },
          {
            accessorKey: 'date',
            header: 'Satış tarihi',
            cell: ({ row }) => dateLabel(row.original.date),
          },
          {
            accessorKey: 'amount',
            header: 'Tutar',
            cell: ({ row }) => <span data-sensitive>{money(row.original.amount)}</span>,
          },
          {
            id: 'balance',
            header: 'Kalan',
            accessorFn: (s) => saleBalance(s, receipts),
            cell: ({ row }) => (
              <span data-sensitive>{money(saleBalance(row.original, receipts))}</span>
            ),
          },
          { accessorKey: 'installments', header: 'Taksit sayısı' },
          {
            id: 'actions',
            header: 'İşlem',
            enableSorting: false,
            cell: ({ row }) => (
              <Button
                variant="outline"
                disabled={saleBalance(row.original, receipts) <= 0}
                onClick={() => setPayment(row.original.id)}
              >
                Tahsilat ekle
              </Button>
            ),
          },
        ]}
        mobileCard={(s) => (
          <>
            <h3>{s.course}</h3>
            <p>
              {dateLabel(s.date)} · {s.installments} taksit
            </p>
            <div className="mobile-record-meta">
              <span data-sensitive>{money(s.amount)}</span>
              <span data-sensitive>Kalan: {money(saleBalance(s, receipts))}</span>
            </div>
            <Button
              variant="outline"
              disabled={saleBalance(s, receipts) <= 0}
              onClick={() => setPayment(s.id)}
            >
              Tahsilat ekle
            </Button>
          </>
        )}
      />
      <h2 className="subsection-title">Tahsilat geçmişi</h2>
      <DataTable
        name="student-receipts"
        data={receipts}
        getRowId={(r) => r.id}
        columns={[
          {
            accessorKey: 'date',
            header: 'Tahsilat tarihi',
            cell: ({ row }) => dateLabel(row.original.date),
          },
          {
            accessorKey: 'amount',
            header: 'Tutar',
            cell: ({ row }) => <span data-sensitive>{money(row.original.amount)}</span>,
          },
          {
            accessorKey: 'method',
            header: 'Ödeme yöntemi',
            cell: ({ row }) => row.original.method || 'Belirtilmedi',
          },
          {
            id: 'sale',
            header: 'Eğitim',
            accessorFn: (r) => sales.find((s) => s.id === r.saleId)?.course || '—',
          },
        ]}
        mobileCard={(r) => (
          <>
            <h3>{dateLabel(r.date)}</h3>
            <p>{r.method || 'Ödeme yöntemi belirtilmedi'}</p>
            <b data-sensitive>{money(r.amount)}</b>
          </>
        )}
      />
      {payment && <ReceiptDialog key={payment} saleId={payment} onClose={() => setPayment(null)} />}
    </>
  ) : (
    <>
      <Metrics
        items={[
          { label: 'Katıldığı ders', value: stats.present },
          { label: 'Katılmadığı ders', value: stats.absent },
          {
            label: 'Kaydedilen devam',
            value: stats.rate === null ? '—' : `%${stats.rate}`,
            highlight: true,
          },
        ]}
      />
      <h2 className="subsection-title">Yoklama geçmişi</h2>
      <DataTable
        name="student-attendance"
        data={sessions}
        getRowId={(s) => s.id}
        columns={[
          {
            id: 'date',
            header: 'Ders tarihi',
            accessorFn: (s) => `${s.date} ${s.time}`,
            cell: ({ row }) => `${dateLabel(row.original.date)} · ${row.original.time}`,
          },
          { accessorKey: 'title', header: 'Ders' },
          { accessorKey: 'groupName', header: 'Grup' },
          { id: 'mark', header: 'Durum', accessorFn: (s) => attendanceLabel(s.marks[id]) },
        ]}
        mobileCard={(s) => (
          <>
            <h3>{s.title}</h3>
            <p>
              {dateLabel(s.date)} · {s.time}
            </p>
            <p>{s.groupName}</p>
            <b>{attendanceLabel(s.marks[id])}</b>
          </>
        )}
      />
    </>
  );
}
