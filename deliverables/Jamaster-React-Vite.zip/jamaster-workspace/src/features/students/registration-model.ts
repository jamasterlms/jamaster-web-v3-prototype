import { z } from 'zod';
import { scheduledResults } from '../meetings/meeting-options.ts';
import {
  birthDateSchema,
  emailSchema,
  profileImageSchema,
  isDateTime,
  phoneSchema,
  optionalPhoneSchema,
} from '../../lib/validation.ts';
export const registrationSchema = z
  .object({
    studentType: z.enum(['INDIVIDUAL', 'CORPORATE', 'CORPORATE_EMPLOYEE']),
    meetingType: z.enum(['PHONE', 'EMAIL', 'WHATSAPP', 'SOCIAL_MEDIA', 'FACE_TO_FACE', 'SMS']),
    meetingScore: z.number().int().min(1).max(5),
    name: z.string().trim().min(2, 'Ad soyad en az iki karakter olmalıdır.'),
    email: emailSchema,
    phone: phoneSchema,
    checkPhone: z.boolean(),
    identityNumber: z
      .string()
      .trim()
      .max(30, 'Kimlik / pasaport numarası en fazla 30 karakter olabilir.'),
    birthDate: birthDateSchema,
    birthPlace: z.string().trim().max(120),
    secondPhone: optionalPhoneSchema,
    address: z.string().trim().max(1000, 'Adres en fazla 1000 karakter olabilir.'),
    image: profileImageSchema,
    courseType: z.enum(['GROUP', 'INDIVIDUAL']),
    course: z.string().trim().min(1, 'Eğitim seçin.'),
    level: z.union([z.enum(['A1', 'A2', 'B1', 'B2', 'C1', 'C2']), z.literal('')]),
    subLevel: z.string(),
    dayPreference: z.enum(['WEEKDAY', 'WEEKEND', 'ALL_WEEK', 'CUSTOM']),
    timePreference: z.enum(['MORNING', 'NOON', 'EVENING', 'LATE_EVENING', 'NIGHT', 'CUSTOM']),
    customDays: z.string().trim().max(160).default(''),
    customTime: z.string().trim().max(160).default(''),
    source: z.string(),
    occupation: z.union([z.enum(['STUDENT', 'EMPLOYEE', 'UNEMPLOYED']), z.literal('')]),
    status: z.enum(['ACTIVE', 'INACTIVE']),
    institution: z.string(),
    company: z.string(),
    advisor: z.string().trim().min(2, 'Danışman adını girin.'),
    meetingResult: z.enum([
      'APPOINTMENT',
      'CALLBACK',
      'NEGATIVE',
      'SALE',
      'COMPLETED',
      'SMS_NOTIFICATION',
      'EMAIL_NOTIFICATION',
      'PENDING',
    ]),
    meetingDate: z.string(),
    negativeReason: z.string(),
    meetingNote: z.string().trim().max(1500, 'Görüşme notu en fazla 1500 karakter olabilir.'),
  })
  .superRefine((v, c) => {
    if (scheduledResults.has(v.meetingResult) && !isDateTime(v.meetingDate))
      c.addIssue({
        code: 'custom',
        path: ['meetingDate'],
        message: 'Bu görüşme sonucu için tarih ve saat seçin.',
      });
    if (v.subLevel && ![`${v.level}.1`, `${v.level}.2`].includes(v.subLevel))
      c.addIssue({
        code: 'custom',
        path: ['subLevel'],
        message: 'Seçilen seviyeye uygun bir alt seviye seçin.',
      });
    if (v.dayPreference === 'CUSTOM' && !v.customDays)
      c.addIssue({
        code: 'custom',
        path: ['customDays'],
        message: 'Tercih edilen günleri belirtin.',
      });
    if (v.timePreference === 'CUSTOM' && !v.customTime)
      c.addIssue({
        code: 'custom',
        path: ['customTime'],
        message: 'Tercih edilen saatleri belirtin.',
      });
    if (v.meetingResult === 'NEGATIVE' && !v.negativeReason)
      c.addIssue({
        code: 'custom',
        path: ['negativeReason'],
        message: 'Olumsuzluk nedenini seçin.',
      });
  });
export type RegistrationDraft = z.infer<typeof registrationSchema>;
export const emptyRegistration: RegistrationDraft = {
  studentType: 'INDIVIDUAL',
  meetingType: 'PHONE',
  meetingScore: 3,
  name: '',
  email: '',
  phone: '',
  checkPhone: false,
  identityNumber: '',
  birthDate: '',
  birthPlace: '',
  secondPhone: '',
  address: '',
  image: '',
  courseType: 'GROUP',
  course: 'Genel İngilizce',
  level: '',
  subLevel: '',
  dayPreference: 'WEEKDAY',
  timePreference: 'EVENING',
  customDays: '',
  customTime: '',
  source: '',
  occupation: '',
  status: 'ACTIVE',
  institution: '',
  company: '',
  advisor: 'Furkan Çolak',
  meetingResult: 'PENDING',
  meetingDate: '',
  negativeReason: '',
  meetingNote: '',
};
export const studentTypes = [
  ['INDIVIDUAL', 'Bireysel'],
  ['CORPORATE', 'Kurumsal'],
  ['CORPORATE_EMPLOYEE', 'Kurum çalışanı'],
];
export const dayPeriods = [
  ['WEEKDAY', 'Hafta içi'],
  ['WEEKEND', 'Hafta sonu'],
  ['ALL_WEEK', 'Tüm hafta'],
  ['CUSTOM', 'Özel'],
];
export const timePeriods = [
  ['MORNING', 'Sabah'],
  ['NOON', 'Öğle'],
  ['EVENING', 'Akşam'],
  ['LATE_EVENING', 'Geç akşam'],
  ['NIGHT', 'Gece'],
  ['CUSTOM', 'Özel'],
];
