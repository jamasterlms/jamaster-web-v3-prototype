import { DateRangeFilter } from '@/components/forms/date-range-filter';
import { useEntityNavigation } from '@/features/entities/use-entity-navigation';
import { useWorkspace } from '@/app/workspace-provider';
import { PageNavigation } from '@/components/navigation/page-navigation';
import { SearchField } from '@/components/shared/feature-primitives';
import { Icon } from '@/components/shared/icon';
import { IconButton, PageHeading, Person, StatusBadge } from '@/components/shared/primitives';
import { Button } from '@/components/ui/button';
import { DataTable } from '@/components/ui/data-table';
import { MultiSelect } from '@/components/ui/multi-select';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { usePageState } from '@/hooks/use-page-state';
import { dateTR, downloadCSV, normalize } from '@/lib/format';
import type { Student } from '@/types';
import type { ColumnDef } from '@tanstack/react-table';
import { Link, useLocation } from 'react-router-dom';
export function StudentsPage() {
  const openEntity = useEntityNavigation();
  const { pathname } = useLocation();
  const status = pathname.endsWith('/past')
    ? 'Geçmiş'
    : pathname.endsWith('/potential')
      ? 'Potansiyel'
      : 'Aktif';
  const { state, openModal } = useWorkspace();
  const [query, setQuery] = usePageState('search', ''),
    [types, setTypes] = usePageState<string[]>('studentType', []),
    [sort, setSort] = usePageState('sortOrder', 'createdAt:desc');
  const [groups, setGroups] = usePageState<string[]>('groups', []),
    [courses, setCourses] = usePageState<string[]>('courses', []),
    [advisors, setAdvisors] = usePageState<string[]>('advisors', []),
    [payments, setPayments] = usePageState<string[]>('payments', []),
    [range, setRange] = usePageState('dateRange', { from: '', to: '' });
  const list = state.students
    .filter(
      (s) =>
        s.status === status &&
        (!groups.length || groups.includes(s.group || 'Atanmadı')) &&
        (!courses.length || courses.includes(s.course)) &&
        (!advisors.length || advisors.includes(s.advisor || 'Atanmadı')) &&
        (!payments.length || payments.includes(s.payment)) &&
        (!range.from || s.date >= range.from) &&
        (!range.to || s.date <= range.to) &&
        (!types.length || types.includes(s.type)) &&
        normalize(s.name + ' ' + s.id + ' ' + s.email + ' ' + s.phone).includes(normalize(query)),
    )
    .sort((a, b) => {
      const field = sort.split(':')[0],
        direction = sort.endsWith('asc') ? 1 : -1;
      return (
        direction *
        (field === 'name'
          ? a.name.localeCompare(b.name, 'tr')
          : field === 'studentNumber'
            ? a.id - b.id
            : a.date.localeCompare(b.date))
      );
    });
  const exportRows = (rows: Student[]) =>
    downloadCSV('jamaster-ogrenciler.csv', [
      ['Ad soyad', 'No', 'Telefon', 'Öğrenci tipi', 'Durum', 'Kayıt tarihi', 'Danışman'],
      ...rows.map((s) => [
        s.name,
        s.id,
        s.phone,
        s.type,
        s.status,
        s.date,
        s.advisor || 'Atanmadı',
      ]),
    ]);
  const actions = (s: Student) => (
    <div className="flex gap-1">
      <IconButton
        icon="message-square"
        label={`${s.name} ile görüşme`}
        onClick={() => openModal({ type: 'meeting', id: s.id })}
      />
      <Button variant="ghost" size="icon" asChild>
        <Link to={`/admin/students/${s.id}`} aria-label={`${s.name} detayları`}>
          <Icon name="arrow-up-right" />
        </Link>
      </Button>
    </div>
  );
  const columns: ColumnDef<Student>[] = [
    {
      accessorKey: 'name',
      header: 'Ad Soyad',
      cell: ({ row }) => (
        <Link to={`/admin/students/${row.original.id}`}>
          <Person student={row.original} />
        </Link>
      ),
    },
    { accessorKey: 'id', header: 'No' },
    { accessorKey: 'phone', header: 'Telefon' },
    { accessorKey: 'type', header: 'Öğrenci Tipi' },
    {
      accessorKey: 'status',
      header: 'Durum',
      cell: ({ row }) => <StatusBadge>{row.original.status}</StatusBadge>,
    },
    {
      accessorKey: 'date',
      header: 'Kayıt Tarihi',
      cell: ({ row }) => dateTR(row.original.date) + ' ' + row.original.date.slice(0, 4),
    },
    { id: 'advisor', accessorFn: (s) => s.advisor || 'Atanmadı', header: 'Danışman' },
    {
      id: 'actions',
      header: 'İşlemler',
      enableSorting: false,
      enableHiding: false,
      cell: ({ row }) => actions(row.original),
    },
  ];
  return (
    <>
      <PageHeading title="Öğrenciler" description="Kayıtlar, eğitimler ve öğrenci bilgileri.">
        <Button asChild>
          <Link to="/admin/students/register">
            <Icon name="plus" />
            Yeni öğrenci
          </Link>
        </Button>
      </PageHeading>
      <PageNavigation
        items={[
          {
            to: '/admin/students',
            label: 'Aktif öğrenciler',
            count: state.students.filter((s) => s.status === 'Aktif').length,
          },
          {
            to: '/admin/students/past',
            label: 'Geçmiş öğrenciler',
            count: state.students.filter((s) => s.status === 'Geçmiş').length,
          },
          {
            to: '/admin/students/potential',
            label: 'Potansiyel',
            count: state.students.filter((s) => s.status === 'Potansiyel').length,
          },
        ]}
      />
      <div className="module-toolbar">
        <SearchField
          value={query}
          onChange={setQuery}
          placeholder="Ad, numara, telefon veya e-posta"
        />
        <MultiSelect
          label="Öğrenci tipi"
          value={types}
          onChange={setTypes}
          options={['Bireysel', 'Kurumsal', 'Kurum çalışanı'].map((value) => ({
            value,
            label: value,
          }))}
        />
        <Select value={sort} onValueChange={setSort}>
          <SelectTrigger className="sort-select" aria-label="Sıralama">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {[
              ['createdAt:desc', 'En yeni kayıt'],
              ['createdAt:asc', 'En eski kayıt'],
              ['name:asc', 'Ad A–Z'],
              ['name:desc', 'Ad Z–A'],
              ['studentNumber:asc', 'Numara artan'],
              ['studentNumber:desc', 'Numara azalan'],
            ].map(([v, l]) => (
              <SelectItem key={v} value={v}>
                {l}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {(query || types.length || sort !== 'createdAt:desc') && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setQuery('');
              setTypes([]);
              setSort('createdAt:desc');
            }}
          >
            Sıfırla
          </Button>
        )}
        <IconButton
          icon="download"
          label="Öğrencileri dışa aktar"
          onClick={() => exportRows(list)}
        />
      </div>
      <div className="module-toolbar secondary-filters">
        <MultiSelect
          label="Grup"
          value={groups}
          onChange={setGroups}
          options={[...new Set(state.students.map((s) => s.group || 'Atanmadı'))].map((value) => ({
            value,
            label: value,
          }))}
        />
        <MultiSelect
          label="Eğitim"
          value={courses}
          onChange={setCourses}
          options={[...new Set(state.students.map((s) => s.course))]
            .filter(Boolean)
            .map((value) => ({ value, label: value }))}
        />
        <MultiSelect
          label="Danışman"
          value={advisors}
          onChange={setAdvisors}
          options={[...new Set(state.students.map((s) => s.advisor || 'Atanmadı'))].map(
            (value) => ({ value, label: value }),
          )}
        />
        <MultiSelect
          label="Ödeme durumu"
          value={payments}
          onChange={setPayments}
          options={[...new Set(state.students.map((s) => s.payment))].map((value) => ({
            value,
            label: value,
          }))}
        />
        <DateRangeFilter {...range} onChange={setRange} />
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            setGroups([]);
            setCourses([]);
            setAdvisors([]);
            setPayments([]);
            setRange({ from: '', to: '' });
            setQuery('');
            setTypes([]);
            setSort('createdAt:desc');
          }}
        >
          Tüm filtreleri sıfırla
        </Button>
      </div>
      <DataTable
        onOpen={(s, full) => openEntity({ kind: 'students', id: String(s.id) }, full)}
        manualSorting
        columns={columns}
        data={list}
        getRowId={(s) => String(s.id)}
        selectionActions={(rows) => (
          <Button size="sm" variant="secondary" onClick={() => exportRows(rows)}>
            <Icon name="download" />
            {rows.length} kaydı dışa aktar
          </Button>
        )}
        mobileCard={(s) => (
          <>
            <Link to={`/admin/students/${s.id}`}>
              <Person student={s} />
            </Link>
            <div className="mobile-record-meta">
              <span>
                #{s.id} · {s.type}
              </span>
              <StatusBadge>{s.status}</StatusBadge>
              <span>{s.phone}</span>
              <span>{dateTR(s.date)}</span>
            </div>
            <div className="mobile-record-actions">{actions(s)}</div>
          </>
        )}
      />
    </>
  );
}
