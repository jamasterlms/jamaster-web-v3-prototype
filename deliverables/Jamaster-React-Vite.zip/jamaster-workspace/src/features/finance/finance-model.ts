import type { WorkspaceState } from '../../app/workspace-reducer.ts';
import { splitInstallments } from '../../lib/payments.ts';
import { isDate, localDate } from '../../lib/validation.ts';
import type { Student } from '../../types/index.ts';

export type Sale = {
  id: string;
  studentId: number;
  course: string;
  planId?: string;
  amount: number;
  method: string;
  installments: number;
  discount: number;
  date: string;
  dueDates?: string[];
  legacyOverdue?: boolean;
};
export type Receipt = {
  id: string;
  saleId: string;
  studentId: number;
  amount: number;
  method: string;
  date: string;
};
export type FinanceRecords = { sales: Sale[]; receipts: Receipt[] };
const cents = (n: number) => Math.round(n * 100);
function savedObject(value?: string): Record<string, unknown> {
  try {
    const parsed = JSON.parse(value || '{}');
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}
/** Materialize old balances once, without inventing sale or collection dates. */
export function financeRecords(
  state: Pick<WorkspaceState, 'sales' | 'receipts' | 'students' | 'settings'>,
): FinanceRecords {
  if (Array.isArray(state.sales) && Array.isArray(state.receipts))
    return { sales: state.sales, receipts: state.receipts };
  const sales: Sale[] = [],
    receipts: Receipt[] = [];
  state.students
    .filter((s) => s.amount > 0)
    .forEach((s) => {
      const old = savedObject(state.settings[`sale-${s.id}`]);
      const payment = savedObject(state.settings[`receipt-${s.id}`]);
      const sale: Sale = {
        id: `legacy-sale-${s.id}`,
        studentId: s.id,
        course: s.course,
        amount: s.amount,
        method: String(old.method || ''),
        installments:
          Number.isInteger(old.installments) &&
          Number(old.installments) > 0 &&
          Number(old.installments) <= 120
            ? Number(old.installments)
            : 1,
        discount: Number(old.discount) || 0,
        date: isDate(String(old.date || '')) ? String(old.date) : '',
        legacyOverdue: s.payment === 'Gecikmiş',
      };
      sales.push(sale);
      if (['Tamamlandı', 'Ödendi'].includes(s.payment))
        receipts.push({
          id: `legacy-receipt-${s.id}`,
          saleId: sale.id,
          studentId: s.id,
          amount: sale.amount,
          method: String(payment.method || ''),
          date: isDate(String(payment.date || '')) ? String(payment.date) : '',
        });
    });
  return { sales, receipts };
}
export function saleBalance(sale: Sale, receipts: Receipt[]) {
  return (
    Math.max(
      0,
      cents(sale.amount) -
        receipts.filter((r) => r.saleId === sale.id).reduce((n, r) => n + cents(r.amount), 0),
    ) / 100
  );
}
export function dueDates(first: string, count: number) {
  if (!isDate(first) || !Number.isInteger(count) || count < 1 || count > 120) return [];
  const [year, month, day] = first.split('-').map(Number);
  return Array.from({ length: count }, (_, i) => {
    const lastDay = new Date(year, month + i, 0, 12).getDate();
    return localDate(new Date(year, month - 1 + i, Math.min(day, lastDay), 12));
  });
}
export function installmentRows(records: FinanceRecords) {
  return records.sales.flatMap((s) => {
    let collected = records.receipts
      .filter((r) => r.saleId === s.id)
      .reduce((n, r) => n + cents(r.amount), 0);
    return splitInstallments(s.amount, s.installments).map((amount, i) => {
      const paid = Math.min(cents(amount), collected);
      collected -= paid;
      return {
        id: `${s.id}:${i}`,
        saleId: s.id,
        studentId: s.studentId,
        course: s.course,
        number: i + 1,
        amount,
        paid: paid / 100,
        balance: (cents(amount) - paid) / 100,
        date: s.dueDates?.[i] || '',
      };
    });
  });
}
export function validateReceipt(receipt: Receipt, records: FinanceRecords) {
  const sale = records.sales.find(
    (s) => s.id === receipt.saleId && s.studentId === receipt.studentId,
  );
  if (!sale) return 'Tahsilata ait satış bulunamadı.';
  if (!isDate(receipt.date)) return 'Geçerli bir tahsilat tarihi seçin.';
  if (sale.date && receipt.date < sale.date) return 'Tahsilat tarihi satış tarihinden önce olamaz.';
  if (!['Nakit', 'Havale / EFT', 'Kredi kartı'].includes(receipt.method))
    return 'Ödeme yöntemi seçin.';
  if (
    !Number.isFinite(receipt.amount) ||
    cents(receipt.amount) <= 0 ||
    Math.abs(receipt.amount * 100 - cents(receipt.amount)) > 0.00001
  )
    return 'Sıfırdan büyük, en fazla iki ondalıklı tutar girin.';
  if (cents(receipt.amount) > cents(saleBalance(sale, records.receipts)))
    return 'Tahsilat tutarı kalan bakiyeyi aşamaz.';
  return null;
}
export function validateSale(sale: Sale) {
  if (!sale.id || !sale.course.trim() || !isDate(sale.date)) return 'Satış bilgilerini tamamlayın.';
  if (
    !Number.isFinite(sale.amount) ||
    sale.amount < 0 ||
    Math.abs(sale.amount * 100 - cents(sale.amount)) > 0.00001
  )
    return 'Geçerli bir satış tutarı girin.';
  if (!Number.isInteger(sale.installments) || sale.installments < 1 || sale.installments > 120)
    return 'Geçerli bir taksit sayısı seçin.';
  if (!Number.isFinite(sale.discount) || sale.discount < 0 || sale.discount > 50)
    return 'İndirim oranını kontrol edin.';
  if (!['Nakit', 'Havale / EFT', 'Kredi kartı'].includes(sale.method))
    return 'Ödeme yöntemi seçin.';
  if (
    sale.dueDates?.length !== sale.installments ||
    sale.dueDates.some(
      (date, i) => !isDate(date) || date < sale.date || (i > 0 && date < sale.dueDates![i - 1]),
    )
  )
    return 'Taksit vadelerini kontrol edin.';
  return null;
}
export function studentFinancials(student: Student, records: FinanceRecords, today = localDate()) {
  const sales = records.sales.filter((s) => s.studentId === student.id);
  const amount = sales.reduce((n, s) => n + cents(s.amount), 0) / 100;
  const balance = sales.reduce((n, s) => n + cents(saleBalance(s, records.receipts)), 0) / 100;
  const overdue =
    installmentRows({ ...records, sales }).some((r) => r.date && r.date < today && r.balance > 0) ||
    sales.some((s) => s.legacyOverdue && saleBalance(s, records.receipts) > 0);
  const payment =
    balance === 0
      ? 'Tamamlandı'
      : overdue
        ? 'Gecikmiş'
        : balance < amount
          ? 'Kısmi ödeme'
          : 'Bekliyor';
  return { ...student, amount, payment };
}
export const inPeriod = (date: string, period: string) =>
  period === 'all' || (!!date && date.startsWith(period));
export function reportPeriods(dates: string[], today = localDate()) {
  return [...new Set([today.slice(0, 7), ...dates.filter(isDate).map((d) => d.slice(0, 7))])]
    .sort()
    .reverse();
}
export const periodLabel = (period: string) =>
  period === 'all'
    ? 'Tüm dönemler'
    : new Date(`${period}-01T12:00:00`).toLocaleDateString('tr-TR', {
        month: 'long',
        year: 'numeric',
      });
