import { useWorkspace } from '@/app/workspace-provider';
import { PageNavigation } from '@/components/navigation/page-navigation';
import { Icon } from '@/components/shared/icon';
import { PageHeading, StatusBadge } from '@/components/shared/primitives';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { useState } from 'react';
import { toast } from 'sonner';
export { FinanceAnalysisPage } from './finance-analysis-page';
export { LedgerPage } from './financial-ledger';
export function PaymentsPage({ route }: { route: string }) {
  const { state, dispatch } = useWorkspace(),
    history = route.includes('history'),
    [confirm, setConfirm] = useState(false);
  const paid = state.settings.servicePayment === 'paid';
  return (
    <>
      <PageHeading title="Ödemeler" description="Abonelik, hizmet bedelleri ve fatura geçmişi." />
      <PageNavigation
        items={[
          { to: '/admin/payments', label: 'Güncel ödeme' },
          { to: '/admin/payments?tab=history', label: 'Ödeme geçmişi' },
          { to: '/admin/payments/installments', label: 'Öğrenci taksitleri' },
        ]}
      />

      {history ? (
        <Table>
          <TableHeader>
            <TableRow>
              {['Hizmet', 'Dönem', 'Tutar', 'Durum'].map((v) => (
                <TableHead key={v}>{v}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {['Ağustos 2026', 'Temmuz 2026'].map((d) => (
              <TableRow key={d}>
                <TableCell>Jamaster LMS hizmet bedeli</TableCell>
                <TableCell>{d}</TableCell>
                <TableCell>3.500 ₺</TableCell>
                <TableCell>
                  <StatusBadge>Ödendi</StatusBadge>
                </TableCell>
              </TableRow>
            ))}
            {paid && (
              <TableRow>
                <TableCell>Jamaster LMS hizmet bedeli</TableCell>
                <TableCell>Eylül 2026</TableCell>
                <TableCell>3.500 ₺</TableCell>
                <TableCell>
                  <StatusBadge>Ödendi</StatusBadge>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      ) : (
        <div className="subscription-card">
          <div>
            <span className="eyebrow">JAMASTER LMS</span>
            <h2>Şubenizin çalışma alanı</h2>
            <p>Eylül 2026 hizmet dönemi</p>
            <div className="subscription-features">
              <span>
                <Icon name="check" />
                Öğrenci ve eğitim yönetimi
              </span>
              <span>
                <Icon name="check" />
                Finans ve görüşme takibi
              </span>
              <span>
                <Icon name="check" />
                Raporlar ve ekip yönetimi
              </span>
            </div>
          </div>
          <div className="subscription-bill">
            <StatusBadge>{paid ? 'Ödendi' : 'Ödeme bekliyor'}</StatusBadge>
            <b data-sensitive>3.500 ₺</b>
            <small>Son ödeme · 12 Eylül 2026</small>
            <Button disabled={paid} onClick={() => setConfirm(true)}>
              Ödeme kaydı ekle
            </Button>
          </div>
        </div>
      )}
      <Dialog open={confirm} onOpenChange={setConfirm}>
        <DialogContent className={'jam-modal'}>
          <DialogHeader>
            <DialogTitle>{'Hizmet ödemesi kaydı'}</DialogTitle>
            <DialogDescription>
              {'Eylül 2026 hizmet bedeline ait ödeme bilgisini kaydedin.'}
            </DialogDescription>
          </DialogHeader>
          <div className="payment-amount">3.500 ₺</div>
          <p className="muted">Bu işlem fatura durumunu ödenmiş olarak işaretler.</p>
          <div className="form-actions">
            <Button variant="outline" onClick={() => setConfirm(false)}>
              Vazgeç
            </Button>
            <Button
              onClick={() => {
                dispatch({ type: 'settings/save', values: { servicePayment: 'paid' } });
                setConfirm(false);
                toast.success('Ödeme kaydı eklendi.');
              }}
            >
              Kaydı tamamla
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
