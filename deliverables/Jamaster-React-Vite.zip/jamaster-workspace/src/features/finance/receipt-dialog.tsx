import { DialogFooter } from '@/components/ui/dialog';
import { useWorkspace } from '@/app/workspace-provider';
import { Person } from '@/components/shared/primitives';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { money } from '@/lib/format';
import { localDate } from '@/lib/validation';
import { useState } from 'react';
import { toast } from 'sonner';
import { financeRecords, saleBalance, validateReceipt } from './finance-model';

export function ReceiptDialog({
  saleId,
  initialAmount,
  onClose,
}: {
  saleId: string;
  initialAmount?: number;
  onClose: () => void;
}) {
  const { state, dispatch } = useWorkspace();
  const records = financeRecords(state),
    sale = records.sales.find((s) => s.id === saleId);
  const student = state.students.find((s) => s.id === sale?.studentId);
  const balance = sale ? saleBalance(sale, records.receipts) : 0;
  const [amount, setAmount] = useState(String(Math.min(initialAmount ?? balance, balance)));
  const [date, setDate] = useState(localDate());
  const [method, setMethod] = useState('Havale / EFT');
  const [error, setError] = useState('');
  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) onClose();
      }}
    >
      <DialogContent className="jam-modal">
        <DialogHeader>
          <DialogTitle>Tahsilat kaydı</DialogTitle>
          <DialogDescription>
            Ödenen tutarı ve ödeme tarihini kaydedin. Kısmi ödeme ekleyebilirsiniz.
          </DialogDescription>
        </DialogHeader>
        {sale && student ? (
          <form
            className="dialog-form"
            onSubmit={(e) => {
              e.preventDefault();
              const receipt = {
                id: crypto.randomUUID(),
                saleId,
                studentId: student.id,
                amount: Number(amount),
                date,
                method,
              };
              const issue =
                date > localDate()
                  ? 'Tahsilat tarihi gelecekte olamaz.'
                  : validateReceipt(receipt, financeRecords(state));
              if (issue) {
                setError(issue);
                return;
              }
              dispatch({ type: 'receipt/save', receipt });
              toast.success('Tahsilat kaydedildi; kalan bakiye güncellendi.');
              onClose();
            }}
          >
            <div className="dialog-form-body">
              <Person student={student} />
              <div className="detail-grid">
                <div>
                  <small>Eğitim</small>
                  <b>{sale.course}</b>
                </div>
                <div>
                  <small>Kalan bakiye</small>
                  <b data-sensitive>{money(balance)}</b>
                </div>
              </div>
              {sale.installments > 1 && (
                <p className="muted">
                  Tahsilat, en eski açık taksitten başlayarak ödeme planına uygulanır.
                </p>
              )}
              <fieldset className="form-section" data-form-section="required">
                <legend>
                  Ödeme bilgileri <span>Zorunlu</span>
                </legend>
                <div className="form-grid two">
                  <div className="form-field">
                    <Label htmlFor="receipt-amount">Tahsil edilen tutar (₺) *</Label>
                    <Input
                      id="receipt-amount"
                      type="number"
                      inputMode="decimal"
                      min="0.01"
                      max={balance}
                      step="0.01"
                      required
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                    />
                  </div>
                  <div className="form-field">
                    <Label htmlFor="receipt-date">Tahsilat tarihi *</Label>
                    <Input
                      id="receipt-date"
                      type="date"
                      min={sale.date || undefined}
                      max={localDate()}
                      required
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                    />
                  </div>
                </div>
                <div className="form-field">
                  <Label htmlFor="receipt-method">Ödeme yöntemi *</Label>
                  <Select value={method} onValueChange={setMethod}>
                    <SelectTrigger id="receipt-method">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {['Havale / EFT', 'Nakit', 'Kredi kartı'].map((m) => (
                        <SelectItem key={m} value={m}>
                          {m}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </fieldset>
              {error && (
                <p role="alert" className="field-error">
                  {error}
                </p>
              )}
            </div>
            <DialogFooter className="form-actions">
              <Button type="button" variant="outline" onClick={onClose}>
                Vazgeç
              </Button>
              <Button type="submit" disabled={balance <= 0}>
                Tahsilatı kaydet
              </Button>
            </DialogFooter>
          </form>
        ) : (
          <p className="empty-inline">Tahsilata ait satış bulunamadı.</p>
        )}
      </DialogContent>
    </Dialog>
  );
}
