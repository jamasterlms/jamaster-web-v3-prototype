import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Icon } from '@/components/shared/icon';
import { Link } from 'react-router-dom';
const integrations: Record<string, { title: string; fields: [string, string, string?][] }> = {
  sms: {
    title: 'Mutlucell SMS',
    fields: [
      ['username', 'Kullanıcı adı'],
      ['password', 'Şifre', 'password'],
      ['originator', 'Gönderici başlığı'],
    ],
  },
  email: {
    title: 'E-posta / SMTP',
    fields: [
      ['smtpHost', 'SMTP sunucusu'],
      ['smtpPort', 'SMTP portu', 'number'],
      ['smtpUser', 'Kullanıcı e-postası', 'email'],
      ['smtpPass', 'SMTP şifresi', 'password'],
      ['mailerSender', 'Gönderici adı'],
      ['mailerSenderEmail', 'Gönderici e-postası', 'email'],
    ],
  },
  whatsapp: {
    title: 'WhatsApp Business',
    fields: [
      ['phoneNumberId', 'Telefon numarası kimliği'],
      ['businessAccountId', 'İşletme hesabı kimliği'],
      ['apiVersion', 'API sürümü'],
      ['accessToken', 'Erişim anahtarı', 'password'],
      ['webhookVerifyToken', 'Webhook doğrulama anahtarı', 'password'],
      ['appSecret', 'Uygulama gizli anahtarı', 'password'],
    ],
  },
  iyzico: {
    title: 'iyzico ödeme bağlantısı',
    fields: [
      ['clientKey', 'API anahtarı', 'password'],
      ['secretKey', 'Gizli anahtar', 'password'],
    ],
  },
};
export function IntegrationSettings({ section }: { section: string }) {
  // Connection secrets never enter page-state or browser storage.
  const [values, setValues] = useState<Record<string, string>>({}),
    [visible, setVisible] = useState(false);
  const config = integrations[section];
  if (!config)
    return (
      <section className="settings-form">
        <h2>Entegrasyonlar</h2>
        <p className="field-hint">Bağlantıların yapılandırma alanlarını açın.</p>
        <div className="integration-links">
          {Object.entries(integrations).map(([key, c]) => (
            <Button variant="outline" asChild key={key}>
              <Link to={`/admin/settings/${key === 'iyzico' ? 'payment' : key}`}>
                {c.title}
                <Icon name="arrow-up-right" />
              </Link>
            </Button>
          ))}
        </div>
      </section>
    );
  return (
    <section className="settings-form">
      <div className="settings-section-heading">
        <h2>{config.title}</h2>
        <p>Gönderici ve servis bağlantı bilgileri.</p>
      </div>
      <p className="pending-banner">
        Bağlantı henüz kurulmadı. Güvenli kaydetme ve bağlantı testi için sunucu bağlantısı
        gerekiyor.
      </p>
      <fieldset className="form-section" data-form-section="required">
        <legend>
          Bağlantı bilgileri <span>Zorunlu</span>
        </legend>
        <div className="form-grid">
          {config.fields.map(([key, label, type]) => (
            <div className="form-field" key={key}>
              <Label htmlFor={`integration-${key}`}>{label} *</Label>
              <Input
                id={`integration-${key}`}
                type={type === 'password' && visible ? 'text' : type || 'text'}
                placeholder={
                  key === 'smtpPort' ? '587' : key === 'apiVersion' ? 'v23.0' : `${label} girin`
                }
                autoComplete="off"
                min={key === 'smtpPort' ? 1 : undefined}
                max={key === 'smtpPort' ? 65535 : undefined}
                value={values[key] || ''}
                onChange={(e) => setValues({ ...values, [key]: e.target.value })}
              />
            </div>
          ))}
        </div>
      </fieldset>
      {section === 'email' && (
        <div className="setting-switch">
          <Label htmlFor="smtp-secure">TLS / SSL kullan</Label>
          <Switch
            id="smtp-secure"
            checked={values.smtpSecure === 'true'}
            onCheckedChange={(v) => setValues({ ...values, smtpSecure: String(v) })}
          />
        </div>
      )}
      <Button variant="ghost" size="sm" onClick={() => setVisible(!visible)} aria-pressed={visible}>
        <Icon name={visible ? 'eye-off' : 'eye'} />
        {visible ? 'Anahtarları gizle' : 'Anahtarları göster'}
      </Button>
      <div className="form-actions">
        <Button disabled>Bağlantıyı test et</Button>
        <Button disabled>Güvenli kaydet</Button>
      </div>
    </section>
  );
}
