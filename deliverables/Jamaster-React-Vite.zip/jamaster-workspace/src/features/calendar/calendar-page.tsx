import { MultiSelect } from '@/components/ui/multi-select';
import { useIsMobile } from '@/hooks/use-mobile';
import { useWorkspace } from '@/app/workspace-provider';
import { PageNavigation } from '@/components/navigation/page-navigation';
import { Icon } from '@/components/shared/icon';
import { IconButton, PageHeading } from '@/components/shared/primitives';
import { StudentPicker } from '@/components/shared/student-picker';
import { Button } from '@/components/ui/button';
import { Label as UIFieldLabel } from '@/components/ui/label';
import {
  Select as UISelect,
  SelectContent as UISelectContent,
  SelectItem as UISelectItem,
  SelectTrigger as UISelectTrigger,
  SelectValue as UISelectValue,
} from '@/components/ui/select';
import { usePageState } from '@/hooks/use-page-state';
import { eventDate, eventDay, layoutEvents, startOfWeek } from '@/lib/calendar';
import { dateTR } from '@/lib/format';
import { AttendancePage } from './attendance-page';
export function CalendarPage({ attendance = false }: { attendance?: boolean }) {
  const { state, openModal } = useWorkspace();
  const tab = attendance ? 'Yoklamalar' : 'Takvim';
  const today = eventDay(),
    currentWeek = Math.floor((startOfWeek() - 7) / 7);
  const [week, setWeek] = usePageState('week', currentWeek);
  const [day, setDay] = usePageState('day', today);
  const mobile = useIsMobile();
  const [view, setView] = usePageState('view', mobile ? 'Gün' : 'Hafta');
  const [rooms, setRooms] = usePageState<string[]>('rooms', []),
    [eventTypes, setEventTypes] = usePageState<string[]>('eventTypes', []);
  const [teacher, setTeacher] = usePageState('teacher', 'Tümü');
  const days = view === 'Hafta' ? Array.from({ length: 7 }, (_, i) => 7 + week * 7 + i) : [day];
  const events = state.events.filter(
    (e) =>
      days.includes(e.day) &&
      (teacher === 'Tümü' || e.teacher === teacher) &&
      (!rooms.length || rooms.includes(e.room)) &&
      (!eventTypes.length || eventTypes.includes(e.type)),
  );
  const startHour = Math.min(8, ...events.map((e) => Number(e.time.split(':')[0])));
  const endHour = Math.max(
    19,
    ...events.map((e) =>
      Math.ceil((Number(e.time.slice(0, 2)) * 60 + Number(e.time.slice(3)) + e.duration) / 60),
    ),
  );
  const hourCount = Math.min(24, endHour) - startHour;
  return (
    <>
      <PageHeading
        title="Ders Programı"
        description="Dersleri, görüşmeleri ve yoklamaları bir arada yönetin."
      >
        <StudentPicker mode="meeting">
          <Button>
            <Icon name="plus" />
            Görüşme ekle
          </Button>
        </StudentPicker>
      </PageHeading>
      <PageNavigation
        items={[
          { to: '/admin/calendar', label: 'Takvim' },
          { to: '/admin/calendar/pollings', label: 'Yoklamalar' },
        ]}
      />

      {tab === 'Takvim' ? (
        <>
          <div className="calendar-toolbar">
            <h2>
              {dateTR(new Date(2026, 8, days[0]))}{' '}
              {days.length > 1 ? `– ${dateTR(eventDate(days.at(-1)!))}` : ''}{' '}
              {eventDate(days.at(-1)!).getFullYear()}
            </h2>
            <div className="flex items-center gap-2 flex-wrap">
              <div className="form-field choice-field">
                <UIFieldLabel htmlFor="calendar-page-select-1">{'Öğretmen'}</UIFieldLabel>
                <UISelect name={undefined} value={teacher || undefined} onValueChange={setTeacher}>
                  <UISelectTrigger
                    id="calendar-page-select-1"
                    className="filter-select"
                    aria-label={'Öğretmen'}
                  >
                    <UISelectValue placeholder={'Seçin'} />
                  </UISelectTrigger>
                  <UISelectContent position="popper">
                    {(
                      ['Tümü', ...new Set(state.events.map((e) => e.teacher))] as (
                        | string
                        | { value: string; label: string }
                      )[]
                    ).map((option) => (
                      <UISelectItem
                        key={typeof option === 'string' ? option : option.value}
                        value={typeof option === 'string' ? option : option.value}
                      >
                        {typeof option === 'string' ? option : option.label}
                      </UISelectItem>
                    ))}
                  </UISelectContent>
                </UISelect>
              </div>
              <div className="form-field choice-field">
                <UIFieldLabel htmlFor="calendar-page-select-2">{'Görünüm'}</UIFieldLabel>
                <UISelect
                  name={undefined}
                  value={view || undefined}
                  onValueChange={(next) => {
                    if (next === 'Hafta') setWeek(Math.floor((day - 7) / 7));
                    else if (day < 7 + week * 7 || day > 13 + week * 7) setDay(7 + week * 7);
                    setView(next);
                  }}
                >
                  <UISelectTrigger
                    id="calendar-page-select-2"
                    className="filter-select"
                    aria-label={'Görünüm'}
                  >
                    <UISelectValue placeholder={'Seçin'} />
                  </UISelectTrigger>
                  <UISelectContent position="popper">
                    {(['Hafta', 'Gün'] as (string | { value: string; label: string })[]).map(
                      (option) => (
                        <UISelectItem
                          key={typeof option === 'string' ? option : option.value}
                          value={typeof option === 'string' ? option : option.value}
                        >
                          {typeof option === 'string' ? option : option.label}
                        </UISelectItem>
                      ),
                    )}
                  </UISelectContent>
                </UISelect>
              </div>
              <IconButton
                icon="chevron-left"
                label="Önceki dönem"
                onClick={() => (view === 'Hafta' ? setWeek(week - 1) : setDay(day - 1))}
              />
              <Button
                variant="outline"
                onClick={() => {
                  setWeek(currentWeek);
                  setDay(today);
                }}
              >
                Bugün
              </Button>
              <IconButton
                icon="chevron-right"
                label="Sonraki dönem"
                onClick={() => (view === 'Hafta' ? setWeek(week + 1) : setDay(day + 1))}
              />
            </div>
          </div>
          <div className="module-toolbar secondary-filters">
            <MultiSelect
              label="Derslik"
              value={rooms}
              onChange={setRooms}
              options={[...new Set(state.events.map((e) => e.room))]
                .filter(Boolean)
                .map((value) => ({ value, label: value }))}
            />
            <MultiSelect
              label="Etkinlik"
              value={eventTypes}
              onChange={setEventTypes}
              options={[
                { value: 'meeting', label: 'Görüşme' },
                { value: 'lesson', label: 'Ders' },
              ]}
            />
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setTeacher('Tümü');
                setRooms([]);
                setEventTypes([]);
              }}
            >
              Filtreleri sıfırla
            </Button>
          </div>
          <div
            className="schedule-scroll"
            tabIndex={0}
            role="region"
            aria-label="Ders programı; yatay kaydırılabilir"
          >
            <div
              className={`schedule-grid ${view === 'Gün' ? 'day-view' : ''}`}
              style={{ gridTemplateColumns: `3.25rem repeat(${days.length}, minmax(7rem,1fr))` }}
            >
              <div className="schedule-corner" />
              {days.map((d) => (
                <button
                  className={`schedule-day ${d === today ? 'today' : ''}`}
                  key={d}
                  onClick={() => {
                    setDay(d);
                    setView('Gün');
                  }}
                >
                  <span>
                    {new Intl.DateTimeFormat('tr-TR', { weekday: 'short' }).format(
                      new Date(2026, 8, d),
                    )}
                  </span>
                  <b>{new Date(2026, 8, d).getDate()}</b>
                </button>
              ))}
              <div className="schedule-hours" style={{ height: `${hourCount * 5.5}rem` }}>
                {Array.from({ length: hourCount }, (_, i) => (
                  <span key={i} style={{ top: `${i * 5.5}rem` }}>
                    {String(i + startHour).padStart(2, '0')}:00
                  </span>
                ))}
              </div>
              {days.map((d) => (
                <div
                  className={`schedule-column ${d === today ? 'today' : ''}`}
                  key={d}
                  style={{ height: `${hourCount * 5.5}rem` }}
                >
                  {Array.from({ length: hourCount }, (_, i) => (
                    <div className="schedule-line" key={i} style={{ top: `${i * 5.5}rem` }} />
                  ))}
                  {layoutEvents(events.filter((e) => e.day === d)).map(
                    ({ event: e, column, columns }) => {
                      const [hour, minute] = e.time.split(':').map(Number);
                      return (
                        <button
                          key={e.id}
                          data-density={
                            e.duration < 30
                              ? 'tiny'
                              : e.duration < 60
                                ? 'short'
                                : e.duration < 90
                                  ? 'medium'
                                  : 'full'
                          }
                          title={`${e.time} · ${e.title} · ${e.person || e.teacher}`}
                          aria-label={`${e.time} · ${e.title} · ${e.person || e.teacher}`}
                          className={`schedule-event ${e.type === 'meeting' ? 'meeting' : e.color === 'green' ? 'green' : ''}`}
                          style={{
                            top: `${(hour - startHour + minute / 60) * 5.5}rem`,
                            height: `${Math.max((e.duration / 60) * 88 - 4, 20) / 16}rem`,
                            left: `calc(${(column / columns) * 100}% + 2px)`,
                            right: 'auto',
                            width: `calc(${100 / columns}% - 4px)`,
                          }}
                          onClick={() => openModal({ type: 'event', id: e.id })}
                        >
                          <small>
                            {e.time} · {e.duration} dk
                          </small>
                          <strong>{e.title}</strong>
                          <span>{e.person || e.teacher}</span>
                          <small>{e.room}</small>
                        </button>
                      );
                    },
                  )}
                </div>
              ))}
            </div>
          </div>
        </>
      ) : (
        <AttendancePage />
      )}
    </>
  );
}
