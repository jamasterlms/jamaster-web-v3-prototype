export type AttendanceMark = 'present' | 'absent' | null;
export type AttendanceSession = {
  id: string;
  branch: string;
  eventId: number;
  groupId: string;
  groupName: string;
  date: string;
  time: string;
  title: string;
  marks: Record<number, AttendanceMark>;
  updatedAt: string;
};
export const sessionKey = (branch: string, eventId: number) => JSON.stringify([branch, eventId]);
export const attendanceLabel = (mark?: AttendanceMark) =>
  mark === 'present' ? 'Katıldı' : mark === 'absent' ? 'Katılmadı' : 'Bekliyor';
export function attendanceStats(sessions: AttendanceSession[], studentId?: number) {
  const marks = sessions.flatMap((s) =>
    studentId === undefined ? Object.values(s.marks) : [s.marks[studentId]],
  );
  const present = marks.filter((m) => m === 'present').length;
  const absent = marks.filter((m) => m === 'absent').length;
  const total = present + absent;
  return { present, absent, total, rate: total ? Math.round((present / total) * 100) : null };
}
export function studentAttendance(sessions: AttendanceSession[], id: number) {
  return attendanceStats(sessions, id).rate;
}
