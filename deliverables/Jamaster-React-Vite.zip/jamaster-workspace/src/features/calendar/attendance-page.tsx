import { useWorkspace } from '@/app/workspace-provider';
import { EmptyState, Person } from '@/components/shared/primitives';
import { Button } from '@/components/ui/button';
import { DataTable } from '@/components/ui/data-table';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useOperations } from '@/features/operations/operations-provider';
import { usePageState } from '@/hooks/use-page-state';
import { eventDate } from '@/lib/calendar';
import { dateTR } from '@/lib/format';
import { localDate } from '@/lib/validation';
import { toast } from 'sonner';
import { attendanceLabel, sessionKey, type AttendanceMark } from './attendance-model';

export function AttendancePage() {
  const { state, dispatch } = useWorkspace();
  const { operations } = useOperations();
  const [groupId, setGroupId] = usePageState('attendance-group', operations.groups[0]?.id || '');
  const [date, setDate] = usePageState('attendance-date', localDate());
  const [eventId, setEventId] = usePageState('attendance-lesson', '');
  const [drafts, setDrafts] = usePageState<Record<string, Record<number, AttendanceMark>>>(
    'attendance-drafts',
    {},
  );
  const group = operations.groups.find((g) => g.id === groupId);
  const lessons = state.events
    .filter(
      (e) => e.type === 'lesson' && e.groupId === groupId && localDate(eventDate(e.day)) === date,
    )
    .sort((a, b) => a.time.localeCompare(b.time));
  const event = lessons.find((e) => String(e.id) === eventId) || lessons[0];
  const key = event ? sessionKey(state.branch, event.id) : '';
  const saved = (state.attendanceSessions || []).find((s) => s.id === key);
  const pupils = state.students.filter((s) =>
    saved ? Object.hasOwn(saved.marks, s.id) : s.group === group?.name && s.status === 'Aktif',
  );
  const marks = drafts[key] || saved?.marks || {};
  const future = !!event && new Date(`${date}T${event.time}`).getTime() > Date.now();
  const changed = pupils.some((s) => (marks[s.id] ?? null) !== (saved?.marks[s.id] ?? null));
  const setMark = (id: number, value: AttendanceMark) =>
    setDrafts((previous) => ({ ...previous, [key]: { ...marks, [id]: value } }));
  const options = (id: number) => (
    <div className="attendance-options" role="group" aria-label="Yoklama durumu">
      {(['present', 'absent'] as const).map((mark) => (
        <Button
          key={mark}
          size="sm"
          variant={marks[id] === mark ? 'default' : 'outline'}
          aria-pressed={marks[id] === mark}
          disabled={future}
          onClick={() => setMark(id, mark)}
        >
          {attendanceLabel(mark)}
        </Button>
      ))}
      <Button
        size="sm"
        variant="ghost"
        disabled={future || !marks[id]}
        onClick={() => setMark(id, null)}
      >
        Temizle
      </Button>
    </div>
  );
  const history = (state.attendanceSessions || [])
    .filter((s) => s.branch === state.branch && s.groupId === groupId)
    .sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
  return (
    <>
      <div className="module-toolbar attendance-filters">
        <div className="form-field">
          <Label htmlFor="poll-group">Grup</Label>
          <Select
            value={groupId || undefined}
            onValueChange={(v) => {
              setGroupId(v);
              setEventId('');
            }}
          >
            <SelectTrigger id="poll-group">
              <SelectValue placeholder="Grup seçin" />
            </SelectTrigger>
            <SelectContent>
              {operations.groups.map((g) => (
                <SelectItem key={g.id} value={g.id}>
                  {g.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="form-field">
          <Label htmlFor="poll-date">Ders tarihi</Label>
          <Input
            id="poll-date"
            type="date"
            value={date}
            onChange={(e) => {
              setDate(e.target.value);
              setEventId('');
            }}
          />
        </div>
        <div className="form-field">
          <Label htmlFor="poll-lesson">Ders oturumu</Label>
          <Select
            value={event ? String(event.id) : ''}
            onValueChange={setEventId}
            disabled={!lessons.length}
          >
            <SelectTrigger id="poll-lesson">
              <SelectValue placeholder="Ders bulunmuyor" />
            </SelectTrigger>
            <SelectContent>
              {lessons.map((e) => (
                <SelectItem key={e.id} value={String(e.id)}>
                  {e.time} · {e.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      {!group ? (
        <EmptyState text="Yoklama için önce bir grup oluşturun." />
      ) : !event ? (
        <EmptyState text="Bu grup için seçilen tarihte planlanmış ders bulunmuyor. Geçmiş bir ders tarihini seçebilirsiniz." />
      ) : (
        <>
          <div className="section-bar">
            <h2>{event.title}</h2>
            <span className="muted">
              {event.teacher} · {event.room || 'Derslik belirtilmedi'}
            </span>
          </div>
          <p className="muted mb-4">
            {future
              ? 'Ders başlamadan yoklama alınamaz.'
              : 'İşaretlenmeyen öğrenciler bekliyor olarak kalır. Değişiklikler kaydettiğinizde uygulanır.'}
          </p>
          <DataTable
            name={`attendance-${event.id}`}
            data={pupils}
            getRowId={(s) => String(s.id)}
            columns={[
              {
                accessorKey: 'name',
                header: 'Öğrenci',
                cell: ({ row }) => <Person student={row.original} />,
              },
              { id: 'status', header: 'Durum', accessorFn: (s) => attendanceLabel(marks[s.id]) },
              {
                id: 'actions',
                header: 'Yoklama',
                enableSorting: false,
                enableHiding: false,
                cell: ({ row }) => options(row.original.id),
              },
            ]}
            mobileCard={(s) => (
              <>
                <Person student={s} />
                <p>{attendanceLabel(marks[s.id])}</p>
                {options(s.id)}
              </>
            )}
          />
          <div className="form-actions attendance-save">
            <span className="muted" role="status">
              {pupils.filter((s) => marks[s.id]).length} / {pupils.length} öğrenci işaretlendi
              {changed ? ' · Kaydedilmemiş değişiklikler' : saved ? ' · Kaydedildi' : ''}
            </span>
            <Button
              variant="outline"
              disabled={!changed}
              onClick={() =>
                setDrafts((previous) => {
                  const next = { ...previous };
                  delete next[key];
                  return next;
                })
              }
            >
              Değişiklikleri geri al
            </Button>
            <Button
              disabled={future || !pupils.length || !changed}
              onClick={() => {
                dispatch({
                  type: 'attendance/save',
                  session: {
                    id: key,
                    branch: state.branch,
                    eventId: event.id,
                    groupId: group.id,
                    groupName: group.name,
                    title: event.title,
                    date,
                    time: event.time,
                    marks: Object.fromEntries(pupils.map((s) => [s.id, marks[s.id] ?? null])),
                    updatedAt: new Date().toISOString(),
                  },
                });
                setDrafts((previous) => {
                  const next = { ...previous };
                  delete next[key];
                  return next;
                });
                toast.success('Ders yoklaması kaydedildi.');
              }}
            >
              Yoklamayı kaydet
            </Button>
          </div>
        </>
      )}
      {!!history.length && (
        <>
          <h2 className="subsection-title">Kaydedilmiş yoklamalar</h2>
          <div className="attendance-history">
            {history.map((s) => (
              <Button
                key={s.id}
                variant="outline"
                onClick={() => {
                  setDate(s.date);
                  setEventId(String(s.eventId));
                }}
              >
                {dateTR(s.date)} · {s.time}
              </Button>
            ))}
          </div>
        </>
      )}
    </>
  );
}
