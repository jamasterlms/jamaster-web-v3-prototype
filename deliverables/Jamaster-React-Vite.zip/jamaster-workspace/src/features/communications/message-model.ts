import type { MessageDraft } from '../operations/model.ts';

export function switchRecipientMode(
  draft: MessageDraft,
  mode: 'single' | 'bulk',
  groups: string[],
): MessageDraft {
  return {
    ...draft,
    recipientMode: mode,
    // Keep the typed address in the editor when switching back. Bulk saves omit it.
    recipient:
      mode === 'bulk' && !groups.includes(draft.recipient) ? groups[0] || '' : draft.recipient,
  };
}
