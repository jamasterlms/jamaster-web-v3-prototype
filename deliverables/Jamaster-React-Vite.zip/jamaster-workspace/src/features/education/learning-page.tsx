import { DialogFooter } from '@/components/ui/dialog';
import { isDate } from '@/lib/validation';
import { useWorkspace } from '@/app/workspace-provider';
import { PageNavigation } from '@/components/navigation/page-navigation';
import {} from '@/components/shared/feature-primitives';
import { Icon } from '@/components/shared/icon';
import { PageHeading, StatusBadge } from '@/components/shared/primitives';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input as UIFieldInput } from '@/components/ui/input';
import { Label as UIFieldLabel } from '@/components/ui/label';
import {
  Select as UISelect,
  SelectContent as UISelectContent,
  SelectItem as UISelectItem,
  SelectTrigger as UISelectTrigger,
  SelectValue as UISelectValue,
} from '@/components/ui/select';
import { operationalData } from '@/data/institution';
import { useOperations } from '@/features/operations/operations-provider';
import { navigate } from '@/hooks/use-route';
import { useState } from 'react';
import { toast } from 'sonner';
const routes = [
  ['admin/education', 'Eğitimler'],
  ['admin/education/period', 'Dönemler'],
  ['admin/program-terms', 'Program dönemleri'],
  ['admin/curriculum-units', 'Müfredat'],
];
function dateInput(value: string) {
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
  const [day, month, year] = value.split(' '),
    months = [
      'Ocak',
      'Şubat',
      'Mart',
      'Nisan',
      'Mayıs',
      'Haziran',
      'Temmuz',
      'Ağustos',
      'Eylül',
      'Ekim',
      'Kasım',
      'Aralık',
    ];
  return year && months.includes(month)
    ? `${year}-${String(months.indexOf(month) + 1).padStart(2, '0')}-${day.padStart(2, '0')}`
    : '';
}
export function LearningPage({ route }: { route: string }) {
  const { state, dispatch } = useWorkspace(),
    { operations } = useOperations();
  const key = route.endsWith('/period') ? 'period' : route.split('/')[1],
    data = operationalData[key];
  const rows = state.moduleRows[key] || data.rows,
    [editing, setEditing] = useState<{ index?: number; values: string[] } | null>(null),
    [expanded, setExpanded] = useState<number | null>(0);
  const period = key === 'period' || key === 'program-terms',
    curriculum = key === 'curriculum-units';
  const fields = period
    ? key === 'period'
      ? ['Dönem adı', 'Başlangıç', 'Bitiş', 'Eğitim']
      : ['Program adı', 'Eğitim', 'Başlangıç', 'Bitiş']
    : curriculum
      ? ['Birim adı', 'Eğitim / seviye', 'Ders sayısı', 'Sıra']
      : ['Eğitim adı', 'Seviyeler', 'Ders sayısı', 'Aktif öğrenci'];
  const formValues = (values: string[]) =>
    values.map((v, i) =>
      /Başlangıç|Bitiş/.test(fields[i] || '')
        ? dateInput(v)
        : /Ders sayısı|Sıra|Aktif öğrenci/.test(fields[i] || '')
          ? String(parseInt(v, 10) || 0)
          : v,
    );
  return (
    <>
      <PageHeading
        title={data.title}
        description={
          period
            ? 'Eğitim dönemlerini ve program takvimini planlayın.'
            : curriculum
              ? 'Öğrenme hedeflerini adım adım yapılandırın.'
              : 'Eğitim portföyünüzü ve seviye yapılarını yönetin.'
        }
      >
        <Button onClick={() => setEditing({ values: ['', '', '', '', 'Aktif'] })}>
          <Icon name="plus" />
          {data.create}
        </Button>
      </PageHeading>
      <PageNavigation items={routes.map(([path, label]) => ({ to: '/' + path, label }))} />
      {period ? (
        <div className="period-list">
          {rows.map((r, i) => (
            <div className={`period-card ${r[4] === 'Aktif' ? 'current' : ''}`} key={i}>
              <span className="course-symbol tone-0">
                <Icon name="calendar-days" />
              </span>
              <div className="period-info">
                <span className="eyebrow">
                  {r[4] === 'Aktif' ? 'GÜNCEL DÖNEM' : 'EĞİTİM DÖNEMİ'}
                </span>
                <h2>{r[0]}</h2>
                <p>{key === 'period' ? `${r[1]} — ${r[2]}` : `${r[2]} — ${r[3]}`}</p>
              </div>
              <StatusBadge>{r[4]}</StatusBadge>
              <Button
                variant="outline"
                onClick={() => setEditing({ index: i, values: formValues(r) })}
              >
                Düzenle
                <Icon name="pencil" />
              </Button>
            </div>
          ))}
        </div>
      ) : curriculum ? (
        <div className="curriculum-list">
          {rows.map((r, i) => (
            <div className="curriculum-unit" key={i}>
              <button
                className="curriculum-heading"
                onClick={() => setExpanded(expanded === i ? null : i)}
                aria-expanded={expanded === i}
              >
                <span className="unit-number">{r[3]}</span>
                <div>
                  <h2>{r[0]}</h2>
                  <p>
                    {r[1]} · {r[2]}
                  </p>
                </div>
                <Icon name={expanded === i ? 'chevron-down' : 'chevron-right'} />
              </button>
              {expanded === i && (
                <div className="curriculum-body">
                  <h3>Öğrenme alanları</h3>
                  <div className="curriculum-skills">
                    {[
                      'Kelime bilgisi',
                      'Dinleme ve anlama',
                      'Konuşma pratiği',
                      'Yazılı anlatım',
                    ].map((s, j) => (
                      <span key={s}>
                        <i>{j + 1}</i>
                        {s}
                      </span>
                    ))}
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => setEditing({ index: i, values: formValues(r) })}
                  >
                    Birim bilgilerini düzenle
                    <Icon name="pencil" />
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="course-grid">
          {rows.map((r, i) => (
            <Card className="course-card" key={i}>
              <div className={`course-cover tone-${i % 3}`}>
                <Icon name={i === 1 ? 'globe' : 'book-open'} />
                <span>JAMASTER ACADEMY</span>
              </div>
              <div className="course-card-body">
                <StatusBadge>{r[4]}</StatusBadge>
                <h2>{r[0]}</h2>
                <p>{r[1]}</p>
                <div className="course-facts">
                  <span>
                    <Icon name="book-open" />
                    {r[2]}
                  </span>
                  <span>
                    <Icon name="users" />
                    {operations.groups.filter((g) => g.course === r[0]).length} grup
                  </span>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => navigate('admin/groups')}>
                    Grupları aç
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => setEditing({ index: i, values: formValues(r) })}
                  >
                    <Icon name="pencil" />
                    Düzenle
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
      <Dialog
        open={!!editing}
        onOpenChange={(v) => {
          if (!v) setEditing(null);
        }}
      >
        <DialogContent preventOutsideClose className={'jam-modal dialog-wide'}>
          <DialogHeader>
            <DialogTitle>
              {editing?.index === undefined ? data.create || 'Oluştur' : 'Bilgileri düzenle'}
            </DialogTitle>
            <DialogDescription className="sr-only">
              {editing?.index === undefined ? data.create || 'Oluştur' : 'Bilgileri düzenle'}
            </DialogDescription>
          </DialogHeader>
          {editing && (
            <form
              className="dialog-form"
              onSubmit={(e) => {
                e.preventDefault();
                if (period) {
                  const start = editing.values[key === 'period' ? 1 : 2],
                    end = editing.values[key === 'period' ? 2 : 3];
                  if (!isDate(start) || !isDate(end) || end < start) {
                    toast.error('Bitiş tarihi başlangıç tarihinden önce olamaz.');
                    return;
                  }
                }
                const next = rows.map((r) => r.slice());
                if (editing.index === undefined) next.unshift(editing.values);
                else next[editing.index] = editing.values;
                dispatch({ type: 'module/rows', key, rows: next });
                setEditing(null);
                toast.success('Eğitim bilgileri kaydedildi.');
              }}
            >
              <div className="dialog-form-body">
                <div className="form-grid">
                  {fields.map((label, i) => (
                    <div className="form-field" key={label}>
                      <UIFieldLabel htmlFor={`learning-${i}`}>{label}</UIFieldLabel>
                      <UIFieldInput
                        id={`learning-${i}`}
                        name={`learning-${i}`}
                        type={
                          /Başlangıç|Bitiş/.test(label)
                            ? 'date'
                            : /Ders sayısı|Sıra|Aktif öğrenci/.test(label)
                              ? 'number'
                              : 'text'
                        }
                        min={/Ders sayısı|Sıra/.test(label) ? 1 : 0}
                        readOnly={label === 'Aktif öğrenci'}
                        value={editing.values[i]}
                        onChange={(e) =>
                          setEditing({
                            ...editing,
                            values: editing.values.map((v, j) => (i === j ? e.target.value : v)),
                          })
                        }
                        required
                      />
                    </div>
                  ))}
                  <div className="form-field choice-field">
                    <UIFieldLabel htmlFor="learning-page-select-1">{'Durum'}</UIFieldLabel>
                    <UISelect
                      name={undefined}
                      value={editing.values[4] || undefined}
                      onValueChange={(v) =>
                        setEditing({ ...editing, values: [...editing.values.slice(0, 4), v] })
                      }
                    >
                      <UISelectTrigger
                        id="learning-page-select-1"
                        className="filter-select"
                        aria-label={'Durum'}
                      >
                        <UISelectValue placeholder={'Seçin'} />
                      </UISelectTrigger>
                      <UISelectContent position="popper">
                        {(
                          ['Aktif', 'Planlandı', 'Tamamlandı'] as (
                            | string
                            | { value: string; label: string }
                          )[]
                        ).map((option) => (
                          <UISelectItem
                            key={typeof option === 'string' ? option : option.value}
                            value={typeof option === 'string' ? option : option.value}
                          >
                            {typeof option === 'string' ? option : option.label}
                          </UISelectItem>
                        ))}
                      </UISelectContent>
                    </UISelect>
                  </div>
                </div>
              </div>
              <DialogFooter className="form-actions">
                <Button type="button" variant="outline" onClick={() => setEditing(null)}>
                  Vazgeç
                </Button>
                <Button type="submit">Kaydet</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
