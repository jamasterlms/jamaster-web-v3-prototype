import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import type { LearningGroup } from '@/features/operations/model';
import { dayPeriods, timePeriods } from '@/features/students/registration-model';
export const groupTypes = [
  ['IN_PERSON', 'Yüz yüze'],
  ['ONLINE', 'Online'],
  ['HYBRID', 'Hibrit'],
];
export const educationTypes = [
  ['GROUPS', 'Grup'],
  ['PRIVATE', 'Özel ders'],
  ['BUSINESS', 'Kurumsal'],
  ['KIDS', 'Çocuk'],
  ['OTHER', 'Diğer'],
];
export function GroupFields({
  value,
  onChange,
  teachers,
}: {
  value: LearningGroup;
  onChange: (v: LearningGroup) => void;
  teachers: string[];
}) {
  const choice = (
    key: keyof LearningGroup,
    label: string,
    options: string[][],
    optional = false,
  ) => (
    <div className="form-field">
      <Label htmlFor={`group-${key}`}>
        {label}
        {!optional && ' *'}
      </Label>
      <Select
        value={String(value[key] || (optional ? '_unset' : '')) || undefined}
        required={!optional}
        onValueChange={(v) =>
          onChange({
            ...value,
            [key]: v === '_unset' ? undefined : v,
            ...(key === 'level' ? { subLevel: '' } : {}),
          })
        }
      >
        <SelectTrigger id={`group-${key}`} aria-required={!optional}>
          <SelectValue placeholder="Seçin" />
        </SelectTrigger>
        <SelectContent>
          {optional && <SelectItem value="_unset">Belirtilmedi</SelectItem>}
          {options.map(([v, l]) => (
            <SelectItem key={v} value={v}>
              {l}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
  const input = (
    key: 'name' | 'capacity' | 'schedule' | 'room',
    label: string,
    required = false,
  ) => (
    <div className="form-field">
      <Label htmlFor={`group-${key}`}>
        {label}
        {required && ' *'}
      </Label>
      <Input
        id={`group-${key}`}
        required={required}
        placeholder={key === 'capacity' ? '16' : `${label} girin`}
        type={key === 'capacity' ? 'number' : 'text'}
        min={key === 'capacity' ? 1 : undefined}
        max={key === 'capacity' ? 100 : undefined}
        minLength={key === 'name' ? 2 : undefined}
        maxLength={240}
        value={value[key]}
        onChange={(e) =>
          onChange({
            ...value,
            [key]: key === 'capacity' ? Number(e.target.value) : e.target.value,
          })
        }
      />
    </div>
  );
  return (
    <>
      <fieldset className="form-section" data-form-section="required">
        <legend>
          Grup ve eğitim bilgileri <span>Zorunlu</span>
        </legend>
        <div className="form-grid">
          {input('name', 'Grup adı', true)}
          {choice(
            'course',
            'Eğitim',
            [
              ...new Set(
                ['Genel İngilizce', 'IELTS Hazırlık', 'İş İngilizcesi', value.course].filter(
                  Boolean,
                ),
              ),
            ].map((v) => [v, v]),
          )}
          {choice('groupType', 'Grup tipi', groupTypes)}
          {choice('educationType', 'Eğitim tipi', educationTypes)}
          {choice(
            'level',
            'Seviye',
            ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'].map((v) => [v, v]),
          )}
          {choice(
            'subLevel',
            'Alt seviye',
            value.level ? [1, 2].map((n) => [`${value.level}.${n}`, `${value.level}.${n}`]) : [],
          )}
          {choice(
            'teacher',
            'Öğretmen',
            [...new Set([...teachers, value.teacher].filter(Boolean))].map((v) => [v, v]),
          )}
          {input('capacity', 'Kapasite', true)}
          {choice('dayPeriod', 'Gün dilimi', dayPeriods)}
          {choice('timePeriod', 'Zaman dilimi', timePeriods)}
        </div>
      </fieldset>
      <fieldset className="form-section form-section-optional" data-form-section="optional">
        <legend>
          Program ve ek bilgiler <span>İsteğe bağlı</span>
        </legend>
        <p className="form-section-description">
          Derslik ve program bilgileri henüz belli değilse daha sonra tamamlayabilirsiniz.
        </p>
        <div className="form-grid">
          {choice(
            'programTermId',
            'Program dönemi',
            [
              ['2026-fall', '2026 Güz'],
              ['2026-winter', '2026 Kış'],
            ],
            true,
          )}
          {input('room', 'Derslik')}
          {input('schedule', 'Ders günleri ve saatleri')}
          <div className="form-field">
            <Label htmlFor="group-status">Durum</Label>
            <Select
              value={value.status}
              onValueChange={(status) =>
                onChange({ ...value, status: status as LearningGroup['status'] })
              }
            >
              <SelectTrigger id="group-status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {['Aktif', 'Planlandı', 'Tamamlandı', 'Pasif'].map((v) => (
                  <SelectItem key={v} value={v}>
                    {v}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="form-field">
          <Label htmlFor="group-description">Açıklama</Label>
          <Textarea
            id="group-description"
            maxLength={1500}
            value={value.description || ''}
            onChange={(e) => onChange({ ...value, description: e.target.value })}
          />
        </div>
      </fieldset>
    </>
  );
}
