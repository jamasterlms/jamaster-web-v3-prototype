export const meetingTypes = [
  ['PHONE', 'Telefon', 'phone'],
  ['FACE_TO_FACE', 'Yüz yüze', 'users'],
  ['SMS', 'SMS', 'message-circle'],
  ['WHATSAPP', 'WhatsApp', 'message-square'],
  ['SOCIAL_MEDIA', 'Sosyal medya', 'globe'],
  ['EMAIL', 'E-posta', 'mail'],
];
export const meetingResults = [
  ['APPOINTMENT', 'Randevu'],
  ['CALLBACK', 'Tekrar Aranacak'],
  ['NEGATIVE', 'Olumsuz'],
  ['SALE', 'Satış'],
  ['COMPLETED', 'Tamamlandı'],
  ['SMS_NOTIFICATION', 'SMS ile bilgilendirme'],
  ['EMAIL_NOTIFICATION', 'E-mail ile bilgilendirme'],
  ['PENDING', 'Beklemede'],
];
export const negativeReasons = [
  'Fiyat yüksek',
  'Zaman uygun değil',
  'Lokasyon uzak',
  'İlgilenmedi',
  'Başka kuruma kayıt oldu',
  'Diğer',
];
export const scheduledResults = new Set([
  'APPOINTMENT',
  'CALLBACK',
  'SMS_NOTIFICATION',
  'EMAIL_NOTIFICATION',
]);
export const quickReplies = [
  'Eğitim programı ve fiyat bilgisi paylaşıldı.',
  'Öğrenci uygun bir zamanda tekrar aranacak.',
  'Seviye tespit görüşmesi planlandı.',
  'Ödeme planı hakkında bilgilendirme yapıldı.',
];
export const labelFor = (options: string[][], value: string) =>
  options.find((item) => item[0] === value)?.[1] || value;
