import { useWorkspace } from '@/app/workspace-provider';
import { Metrics, ProgressMeter, SearchField } from '@/components/shared/feature-primitives';
import { Icon } from '@/components/shared/icon';
import { EmptyState, PageHeading, Person } from '@/components/shared/primitives';
import { Button } from '@/components/ui/button';
import { DataTable } from '@/components/ui/data-table';
import { pageFor } from '@/data/navigation';
import { attendanceStats } from '@/features/calendar/attendance-model';
import { LineChart } from '@/features/dashboard/charts';
import { useOperations } from '@/features/operations/operations-provider';
import { usePageState } from '@/hooks/use-page-state';
import { downloadCSV, normalize } from '@/lib/format';
import { localDate } from '@/lib/validation';
import type { Student } from '@/types';
import { distribution } from './report-model';
const definitions: Record<string, { description: string; test: (s: Student) => boolean }> = {
  'active-students': {
    description: 'Eğitimi devam eden aktif öğrenciler.',
    test: (s) => s.status === 'Aktif',
  },
  'active-unassigned-students': {
    description: 'Aktif eğitimi olup henüz gruba atanmamış öğrenciler.',
    test: (s) =>
      s.status === 'Aktif' &&
      (!s.group || s.group === 'Henüz atanmadı' || s.group.includes('Grup bekliyor')),
  },
  'attendance-risk-students': {
    description: 'Devam oranı %90’ın altında olan aktif öğrenciler.',
    test: (s) => s.status === 'Aktif' && s.attendance < 90,
  },
  'high-attendance-students': {
    description: 'Devam oranı %94 ve üzerinde olan aktif öğrenciler.',
    test: (s) => s.status === 'Aktif' && s.attendance >= 94,
  },
  'never-attended-students': {
    description: 'Henüz bir derse katılmamış aktif öğrenciler.',
    test: (s) => s.status === 'Aktif' && s.attendance === 0,
  },
  'never-group-assigned': {
    description: 'Henüz ilk grup ataması yapılmamış öğrenciler.',
    test: (s) => !s.group || s.group === 'Henüz atanmadı' || s.group.includes('Grup bekliyor'),
  },
  'reactivation-candidates': {
    description: 'Geçmiş dönemde eğitim almış, yeniden görüşülebilecek öğrenciler.',
    test: (s) => s.status === 'Geçmiş',
  },
  'frozen-students': {
    description: 'Eğitimi dondurulmuş öğrenciler.',
    test: (s) => s.status === 'Dondurulmuş',
  },
  'no-attendance-recently': {
    description: 'Son 30 gündeki kaydedilmiş derslerde devamsızlığı olan aktif öğrenciler.',
    test: () => true,
  },
};
export function EducationDetailPage({ route }: { route: string }) {
  const { state, openModal } = useWorkspace(),
    { operations } = useOperations(),
    [query, setQuery] = usePageState('query', '');
  const slug = route.split('/').at(-1) || '',
    title = pageFor(route).title,
    definition = definitions[slug],
    aggregate = [
      'education-status-distribution',
      'group-assignment-load',
      'attendance-trend',
    ].includes(slug);
  const sessions = (state.attendanceSessions || []).filter((s) => s.branch === state.branch);
  const since = new Date();
  since.setDate(since.getDate() - 30);
  const from = localDate(since),
    today = localDate();
  const students = state.students.map((s) => ({
    ...s,
    attendance: attendanceStats(sessions, s.id).rate ?? -1,
  }));
  let list = definition ? students.filter(definition.test) : [];
  if (
    ['attendance-risk-students', 'high-attendance-students', 'never-attended-students'].includes(
      slug,
    )
  )
    list = list.filter((s) => s.attendance >= 0);
  if (slug === 'no-attendance-recently')
    list = students.filter(
      (s) =>
        s.status === 'Aktif' &&
        sessions.some(
          (record) =>
            record.date >= from && record.date <= today && record.marks[s.id] === 'absent',
        ),
    );
  if (slug === 'no-meeting-recently')
    list = students.filter(
      (s) =>
        s.status === 'Aktif' &&
        !state.meetings.some(
          (m) =>
            m.studentId === s.id &&
            m.createdAt.slice(0, 10) >= from &&
            m.createdAt.slice(0, 10) <= today,
        ),
    );
  if (slug === 'meeting-intensive-students')
    list = students.filter(
      (s) =>
        state.meetings.filter(
          (m) =>
            m.studentId === s.id &&
            m.createdAt.slice(0, 10) >= from &&
            m.createdAt.slice(0, 10) <= today,
        ).length >= 3,
    );
  list = list.filter((s) => normalize(s.name + s.course).includes(normalize(query)));
  const rates = list.filter((s) => s.attendance >= 0);
  const avg = rates.length
    ? Math.round(rates.reduce((n, s) => n + s.attendance, 0) / rates.length)
    : null;
  const daily = [...new Set(sessions.map((s) => s.date))]
    .sort()
    .map((date) => [date, attendanceStats(sessions.filter((s) => s.date === date)).rate] as const)
    .filter((entry): entry is readonly [string, number] => entry[1] !== null);
  const bars: [string, number, number][] =
    slug === 'education-status-distribution'
      ? distribution(
          students,
          (s) => s.status,
          () => 1,
        ).map(([label, count]) => [
          label,
          count,
          students.length ? (count / students.length) * 100 : 0,
        ])
      : operations.groups.map((g) => {
          const count = students.filter((s) => s.group === g.name).length;
          return [g.name, count, g.capacity ? (count / g.capacity) * 100 : 0];
        });
  const exportRows = aggregate
    ? slug === 'attendance-trend'
      ? [['Tarih', 'Devam (%)'], ...daily.map((row) => [...row])]
      : [['Durum / Grup', 'Öğrenci', 'Oran (%)'], ...bars]
    : [
        ['Öğrenci', 'Eğitim', 'Grup', 'Devam (%)'],
        ...list.map((s) => [
          s.name,
          s.course,
          s.group,
          s.attendance < 0 ? 'Belirtilmedi' : s.attendance,
        ]),
      ];
  return (
    <>
      <PageHeading
        title={title}
        description={
          definition?.description ||
          'Seçili eğitim ölçütüne ait kayıtları ve öğrenci durumlarını inceleyin.'
        }
      >
        <Button
          variant="outline"
          onClick={() => downloadCSV('jamaster-egitim-raporu.csv', exportRows)}
        >
          <Icon name="download" />
          CSV indir
        </Button>
      </PageHeading>
      {aggregate ? (
        <div className="analysis-panel">
          <h2>{title}</h2>
          {slug === 'attendance-trend' ? (
            daily.length ? (
              <LineChart
                values={daily.map(([, rate]) => rate)}
                labels={daily.map(([date]) => date)}
                color="#9abfa8"
              />
            ) : (
              <EmptyState text="Devam trendi için kaydedilmiş yoklama bulunmuyor." />
            )
          ) : (
            bars.map(([label, count, percent]) => (
              <div className="analysis-bar" key={label}>
                <div>
                  <span>{label}</span>
                  <b>{count} öğrenci</b>
                </div>
                <ProgressMeter value={percent} label={label} />
              </div>
            ))
          )}
        </div>
      ) : (
        <>
          <Metrics
            items={[
              { label: 'Eşleşen öğrenci', value: list.length },
              { label: 'Ortalama devam', value: avg === null ? '—' : `%${avg}`, highlight: true },
              {
                label: 'Görüşme kaydı',
                value: state.meetings.filter((m) => list.some((s) => s.id === m.studentId)).length,
              },
            ]}
          />
          <div className="module-toolbar">
            <SearchField value={query} onChange={setQuery} placeholder="Raporda öğrenci ara" />
          </div>
          <DataTable
            name="education-report"
            data={list}
            getRowId={(s) => String(s.id)}
            columns={[
              {
                accessorKey: 'name',
                header: 'Öğrenci',
                cell: ({ row }) => <Person student={row.original} />,
              },
              { accessorKey: 'group', header: 'Grup' },
              { accessorKey: 'teacher', header: 'Öğretmen' },
              {
                accessorKey: 'attendance',
                header: 'Kaydedilen devam',
                cell: ({ row }) =>
                  row.original.attendance < 0 ? '—' : `%${row.original.attendance}`,
              },
              {
                id: 'actions',
                header: 'İşlem',
                enableSorting: false,
                cell: ({ row }) => (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      openModal({ type: 'meeting', id: row.original.id, reportMode: true })
                    }
                  >
                    Görüşme
                  </Button>
                ),
              },
            ]}
            mobileCard={(s) => (
              <>
                <Person student={s} />
                <div className="mobile-record-meta">
                  <span>{s.group}</span>
                  <span>{s.teacher}</span>
                  <span>{s.attendance < 0 ? 'Yoklama bulunmuyor' : `%${s.attendance} devam`}</span>
                </div>
                <Button
                  variant="outline"
                  onClick={() => openModal({ type: 'meeting', id: s.id, reportMode: true })}
                >
                  Görüşme
                </Button>
              </>
            )}
          />
        </>
      )}
    </>
  );
}
