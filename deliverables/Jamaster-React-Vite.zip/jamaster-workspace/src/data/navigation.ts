import type { NavigationGroup } from '@/types';
import raw from './navigation.json';
export const navigation = raw as NavigationGroup[];
export function navRoute(path: string) {
  if (path.includes('startDate=')) return 'admin/reports/monthly-meetings';
  return path.replace(/^\//, '');
}
export function navIcon(name: string) {
  return (
    (
      {
        FaWhatsapp: 'message-circle',
        Group: 'group',
        CalendarRange: 'calendar-range',
        HelpCircle: 'circle-help',
      } as Record<string, string>
    )[name] || name.replace(/[A-Z]/g, (letter, index) => (index ? '-' : '') + letter.toLowerCase())
  );
}
export const primaryPages = [
  { id: 'admin/dashboard', title: 'Panel', icon: 'layout-dashboard' },
  { id: 'admin/calendar', title: 'Takvim', icon: 'calendar-days' },
  { id: 'admin/students', title: 'Öğrenciler', icon: 'users' },
  { id: 'admin/education-reports', title: 'Raporlar', icon: 'chart-no-axes-combined' },
];
export const allPages = navigation
  .flatMap((group) =>
    group.items.flatMap((item) => [
      { id: navRoute(item.path), title: item.label, icon: navIcon(item.icon), parent: item },
      ...(item.children || []).map((child) => ({
        id: navRoute(child.path),
        title: child.label,
        icon: navIcon(item.icon),
        parent: item,
      })),
    ]),
  )
  .filter((page, index, array) => array.findIndex((item) => item.id === page.id) === index);
export const pageFor = (route: string) =>
  allPages.find((page) => page.id === route.split('?')[0]) || {
    id: route,
    title: route.startsWith('admin/sales/')
      ? 'Yeni satış'
      : /^admin\/students\/\d+/.test(route)
        ? 'Öğrenci profili'
        : /^admin\/groups\//.test(route)
          ? 'Grup detayları'
          : /^admin\/teachers\//.test(route)
            ? 'Öğretmen profili'
            : /^(admin|super)\/(staff|users)\//.test(route)
              ? 'Personel profili'
              : 'Çalışma alanı',
    icon: 'wallet',
    parent: undefined,
  };
export function operationKey(route: string) {
  const parts = route.split('/');
  if (parts[1] === 'education' && parts[2] === 'period') return 'period';
  if (parts[1] === 'billing') return 'payments';
  return parts[1] || 'groups';
}
