import type { CalendarEvent } from '../types/index.ts';
// Existing event serials use this epoch; keeping it preserves saved calendars.
export const eventDate = (day: number) => new Date(2026, 8, day, 12);
export function eventDay(date = new Date()) {
  return (
    Math.round(
      (Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) - Date.UTC(2026, 8, 1)) /
        86400000,
    ) + 1
  );
}
export function startOfWeek(date = new Date()) {
  return eventDay(date) - ((date.getDay() + 6) % 7);
}
export function layoutEvents(events: CalendarEvent[]) {
  const rows = events
    .map((event) => {
      const [hour, minute] = event.time.split(':').map(Number);
      return {
        event,
        start: hour * 60 + minute,
        end: hour * 60 + minute + event.duration,
        column: 0,
        columns: 1,
      };
    })
    .sort((a, b) => a.start - b.start || b.end - a.end);
  let cluster: typeof rows = [],
    clusterEnd = -1;
  const finish = () => {
    const count = Math.max(1, ...cluster.map((r) => r.column + 1));
    cluster.forEach((r) => {
      r.columns = count;
    });
  };
  for (const row of rows) {
    if (row.start >= clusterEnd) {
      finish();
      cluster = [];
      clusterEnd = -1;
    }
    const used = new Set(cluster.filter((r) => r.end > row.start).map((r) => r.column));
    while (used.has(row.column)) row.column++;
    cluster.push(row);
    clusterEnd = Math.max(clusterEnd, row.end);
  }
  finish();
  return rows;
}
