import { PageHeading } from '@/components/shared/primitives';
import { Button } from '@/components/ui/button';
import { AutomationsPage } from '@/features/administration/automations-page';
import { AnnouncementsPage, FilesPage, SupportPage } from '@/features/administration/content-pages';
import { ContractsPage } from '@/features/administration/contracts-page';
import { TeamPage } from '@/features/administration/team-page';
import { VerificationPage } from '@/features/administration/verification-page';
import { CalendarPage } from '@/features/calendar/calendar-page';
import { CommunicationsPage } from '@/features/communications/communications-page';
import { DashboardPage } from '@/features/dashboard/dashboard-page';
import { GroupsPage } from '@/features/education/groups-page';
import { LearningPage } from '@/features/education/learning-page';
import { TeachersPage } from '@/features/education/teachers-page';
import { ExpensesPage } from '@/features/finance/expenses-page';
import { FinanceAnalysisPage, LedgerPage, PaymentsPage } from '@/features/finance/ledger-page';
import { PricingPage } from '@/features/finance/pricing-page';
import { SalePage } from '@/features/finance/sale-page';
import { EducationDetailPage } from '@/features/insights/education-detail-page';
import { ReportsPage } from '@/features/insights/reports-page';
import { MeetingsPage } from '@/features/meetings/meetings-page';
import { SettingsPage } from '@/features/settings/settings-page';
import { RegistrationPage } from '@/features/students/registration-page';
import { StudentPage } from '@/features/students/student-page';
import { StudentsPage } from '@/features/students/students-page';
import { Link } from 'react-router-dom';
const analyses = new Set([
  'accounting',
  'sales-by-advisor',
  'conversion-funnel',
  'payment-method-performance',
  'discount-impact',
  'cancellation-refund-analysis',
  'pricing-package-performance',
  'revenue-forecast-trend',
  'advisor-revenue-risk',
  'contract-expiry-revenue-risk',
]);
export function PageRouter({ route }: { route: string }) {
  const key = route.split('/')[1],
    create = /\/(form|create)$/.test(route),
    slug = route.split('/').at(-1) || '';
  if (route === 'admin/dashboard') return <DashboardPage />;
  if (route === 'admin/calendar' || route === 'admin/calendar/pollings')
    return <CalendarPage key={route} attendance={route.includes('pollings')} />;
  if (['admin/students', 'admin/students/potential', 'admin/students/past'].includes(route))
    return <StudentsPage key={route} />;
  const studentRoute = route.match(
    /^admin\/students\/(\d+)(?:\/(payments|polling-history|history))?$/,
  );
  if (studentRoute)
    return <StudentPage key={route} id={Number(studentRoute[1])} section={studentRoute[2]} />;
  if (route === 'admin/students/register') return <RegistrationPage />;
  if (route === 'admin/education-reports' || route === 'admin/reports')
    return <ReportsPage finance={route === 'admin/reports'} />;
  if (route.includes('settings') || route.includes('user/account'))
    return <SettingsPage key={route} route={route} />;
  if (/^admin\/sales\/\d+$/.test(route)) return <SalePage key={route} id={Number(slug)} />;
  if (key === 'groups')
    return (
      <GroupsPage
        key={route}
        create={create}
        detailId={!create && route.split('/').length === 3 ? decodeURIComponent(slug) : undefined}
      />
    );
  if (key === 'teachers')
    return (
      <TeachersPage
        key={route}
        create={create}
        detailId={!create && route.split('/').length === 3 ? decodeURIComponent(slug) : undefined}
      />
    );
  if (['education', 'program-terms', 'curriculum-units'].includes(key))
    return <LearningPage key={route} route={route} />;
  if (['meetings', 'monthly-meetings'].includes(slug))
    return key === 'verification-requests' ? (
      <VerificationPage key={route} route={route} />
    ) : (
      <MeetingsPage />
    );
  if (key === 'education-reports') return <EducationDetailPage key={route} route={route} />;
  if (key === 'expenses')
    return <ExpensesPage key={route} create={create} superAdmin={route.startsWith('super/')} />;
  if (key === 'pricing') return <PricingPage key={route} create={create} />;
  if (key === 'reports')
    return analyses.has(slug) ? (
      <FinanceAnalysisPage key={route} route={route} />
    ) : (
      <LedgerPage key={route} route={route} />
    );
  if ((key === 'payments' && slug === 'installments') || route === 'super/branches/payments')
    return <LedgerPage key={route} route={route} />;
  if (key?.startsWith('payments') || key === 'billing')
    return <PaymentsPage key={route} route={route} />;
  if (['sms', 'email', 'whatsapp'].includes(key))
    return <CommunicationsPage key={route} route={route} />;
  if (['staff', 'users', 'branches'].includes(key)) return <TeamPage key={route} route={route} />;
  if (key === 'automations') return <AutomationsPage key={route} create={create} />;
  if (key === 'verification-requests') return <VerificationPage key={route} route={route} />;
  if (key === 'announcements') return <AnnouncementsPage />;
  if (key === 'contracts') return <ContractsPage key={route} create={create} />;
  if (key === 'files') return <FilesPage />;
  if (key === 'support') return <SupportPage />;
  return (
    <>
      <PageHeading
        title="Sayfa bulunamadı"
        description="Menüden bir çalışma alanı seçebilirsiniz."
      />
      <Button asChild>
        <Link to="/admin/dashboard">Panele dön</Link>
      </Button>
    </>
  );
}
