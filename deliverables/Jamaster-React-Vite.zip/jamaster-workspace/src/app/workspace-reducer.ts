import type { AttendanceSession } from '../features/calendar/attendance-model.ts';
import {
  financeRecords,
  studentFinancials,
  validateReceipt,
  validateSale,
  type Receipt,
  type Sale,
} from '../features/finance/finance-model.ts';
import type { CalendarEvent, ChatMessage, Meeting, Student } from '../types/index.ts';
export type WorkspaceState = {
  students: Student[];
  events: CalendarEvent[];
  meetings: Meeting[];
  attendance: Record<number, string>;
  attendanceSessions?: AttendanceSession[];
  sales?: Sale[];
  receipts?: Receipt[];
  moduleRows: Record<string, string[][]>;
  branch: string;
  privacy: boolean;
  chat: ChatMessage[];
  settings: Record<string, string>;
};
export type WorkspaceAction =
  | { type: 'student/save'; student: Student }
  | { type: 'teacher/rename'; previous: string; name: string }
  | { type: 'meeting/save'; meeting: Meeting; event?: CalendarEvent; completedEventId?: number }
  | {
      type: 'group/update';
      id: string;
      previousName: string;
      name: string;
      course: string;
      teacher: string;
      room: string;
    }
  | { type: 'attendance/set'; id: number; status: string }
  | { type: 'attendance/save'; session: AttendanceSession }
  | { type: 'sale/save'; sale: Sale }
  | { type: 'receipt/save'; receipt: Receipt }
  | { type: 'module/rows'; key: string; rows: string[][] }
  | { type: 'branch/set'; branch: string }
  | { type: 'privacy/toggle' }
  | { type: 'chat/add'; messages: ChatMessage[] }
  | { type: 'chat/clear' }
  | { type: 'settings/save'; values: Record<string, string> };
export function workspaceReducer(state: WorkspaceState, action: WorkspaceAction): WorkspaceState {
  switch (action.type) {
    case 'student/save':
      return {
        ...state,
        students: state.students.some((s) => s.id === action.student.id)
          ? state.students.map((s) => (s.id === action.student.id ? action.student : s))
          : [action.student, ...state.students],
        events: state.events.map((event) =>
          event.studentId === action.student.id ||
          state.meetings.some(
            (meeting) => meeting.id === event.id && meeting.studentId === action.student.id,
          )
            ? { ...event, person: action.student.name }
            : event,
        ),
      };
    case 'teacher/rename':
      return {
        ...state,
        students: state.students.map((s) =>
          s.teacher === action.previous ? { ...s, teacher: action.name } : s,
        ),
        events: state.events.map((e) =>
          e.teacher === action.previous ? { ...e, teacher: action.name } : e,
        ),
      };
    case 'meeting/save':
      if (state.meetings.some((m) => m.id === action.meeting.id)) return state;
      return {
        ...state,
        meetings: [action.meeting, ...state.meetings],
        events: [
          ...state.events.map((e) =>
            e.id === action.completedEventId && e.type === 'meeting'
              ? { ...e, completedAt: action.meeting.createdAt }
              : e,
          ),
          ...(action.event ? [action.event] : []),
        ],
      };
    case 'group/update':
      return {
        ...state,
        students: state.students.map((s) =>
          s.group === action.previousName
            ? {
                ...s,
                group: action.name,
                course: action.course,
                teacher: action.teacher,
                profile: { ...s.profile, course: action.course },
              }
            : s,
        ),
        events: state.events.map((e) =>
          e.groupId === action.id ? { ...e, teacher: action.teacher, room: action.room } : e,
        ),
      };
    case 'attendance/set':
      return { ...state, attendance: { ...state.attendance, [action.id]: action.status } };
    case 'attendance/save':
      return {
        ...state,
        attendanceSessions: [
          action.session,
          ...(state.attendanceSessions || []).filter((s) => s.id !== action.session.id),
        ],
      };
    case 'sale/save': {
      const records = financeRecords(state);
      if (
        validateSale(action.sale) ||
        records.sales.some((s) => s.id === action.sale.id) ||
        !state.students.some((s) => s.id === action.sale.studentId)
      )
        return state;
      const next = { sales: [...records.sales, action.sale], receipts: records.receipts };
      return {
        ...state,
        ...next,
        students: state.students.map((s) =>
          s.id === action.sale.studentId ? studentFinancials({ ...s, status: 'Aktif' }, next) : s,
        ),
      };
    }
    case 'receipt/save': {
      const records = financeRecords(state);
      if (
        records.receipts.some((r) => r.id === action.receipt.id) ||
        validateReceipt(action.receipt, records)
      )
        return state;
      const next = { sales: records.sales, receipts: [...records.receipts, action.receipt] };
      return {
        ...state,
        ...next,
        students: state.students.map((s) =>
          s.id === action.receipt.studentId ? studentFinancials(s, next) : s,
        ),
      };
    }
    case 'module/rows':
      return { ...state, moduleRows: { ...state.moduleRows, [action.key]: action.rows } };
    case 'branch/set':
      return { ...state, branch: action.branch };
    case 'privacy/toggle':
      return { ...state, privacy: !state.privacy };
    case 'chat/add':
      return { ...state, chat: [...state.chat, ...action.messages] };
    case 'chat/clear':
      return { ...state, chat: [] };
    case 'settings/save':
      return {
        ...state,
        settings: { ...state.settings, ...action.values },
        branch: action.values.branchName || state.branch,
      };
  }
}
