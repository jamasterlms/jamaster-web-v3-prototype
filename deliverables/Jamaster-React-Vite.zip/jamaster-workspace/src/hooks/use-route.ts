import { useLayoutEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
let visit: ((path: string) => void) | undefined;
const aliases: Record<string, string> = {
  panel: 'admin/dashboard',
  takvim: 'admin/calendar',
  ogrenciler: 'admin/students',
  raporlar: 'admin/education-reports',
};
export function routeURL(route: string) {
  const clean = route.replace(/^[/#]+/, '');
  return '/' + (aliases[clean] || clean || 'admin/dashboard');
}
export function useRoute() {
  const location = useLocation();
  return (location.pathname.replace(/^\//, '') || 'admin/dashboard') + location.search;
}
export function NavigationBridge() {
  const navigate = useNavigate();
  useLayoutEffect(() => {
    visit = (path) => {
      void navigate(path);
    };
    return () => {
      visit = undefined;
    };
  }, [navigate]);
  return null;
}
export function navigate(route: string) {
  visit?.(routeURL(route));
}
