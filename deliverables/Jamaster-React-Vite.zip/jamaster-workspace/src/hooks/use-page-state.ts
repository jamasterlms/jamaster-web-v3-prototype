import { pageStateKey, readPageValue, writePageValue } from '@/app/navigation/page-state-store';
import { useWorkspace } from '@/app/workspace-provider';
import { useEffect, useState, type Dispatch, type SetStateAction } from 'react';
import { useLocation } from 'react-router-dom';
const storage = () => {
  try {
    return typeof sessionStorage === 'undefined' ? undefined : sessionStorage;
  } catch {
    return undefined;
  }
};
// State is scoped to a branch and canonical page; inactive page trees are unmounted.
export function usePageState<T>(
  name: string,
  initial: T | (() => T),
): [T, Dispatch<SetStateAction<T>>] {
  const { pathname } = useLocation(),
    { state } = useWorkspace();
  const key = pageStateKey(state.branch, pathname, name);
  const [value, setValue] = useState<T>(() =>
    readPageValue(storage(), key, initial instanceof Function ? initial() : initial),
  );
  useEffect(() => {
    writePageValue(storage(), key, value);
  }, [key, value]);
  return [value, setValue];
}
