import { DisplayProvider } from '../src/app/display-provider';
import { MemoryRouter } from 'react-router-dom';
import { NavigationProvider } from '../src/app/navigation/navigation-provider';
// Static rendering checks component composition without driving a browser.
import assert from 'node:assert/strict';
import { renderToString } from 'react-dom/server';
import { PageRouter } from '../src/app/page-router';
import { App } from '../src/app/app';
import { WorkspaceProvider, useWorkspace } from '../src/app/workspace-provider';
import { MeetingDialog } from '../src/features/meetings/meeting-dialog';
import { replyFor } from '../src/features/jamai/jamai-panel';
import { OperationsProvider } from '../src/features/operations/operations-provider';
import { allPages } from '../src/data/navigation';
const wrap = (children: React.ReactNode, path = '/admin/dashboard') => (
  <MemoryRouter initialEntries={[path]}>
    <NavigationProvider>
      <OperationsProvider>
        <WorkspaceProvider>
          <DisplayProvider>{children}</DisplayProvider>
        </WorkspaceProvider>
      </OperationsProvider>
    </NavigationProvider>
  </MemoryRouter>
);
import { RegistrationFields } from '../src/features/students/registration-fields';
import { RegistrationReview } from '../src/features/students/registration-review';
import { StudentForm } from '../src/features/students/student-dialogs';
import { GroupFields } from '../src/features/education/group-fields';
import { TeacherFields } from '../src/features/education/teacher-fields';
import { ExpenseFields } from '../src/features/finance/expense-fields';
import { PricingFields } from '../src/features/finance/pricing-fields';
import { groupDraft } from '../src/features/education/group-model';
import { expenseDraft } from '../src/features/finance/expense-model';
import { initialOperations } from '../src/features/operations/model';
import { emptyRegistration, registrationSchema } from '../src/features/students/registration-model';
function checkMarkup(html: string, context: string) {
  const ids = [...html.matchAll(/\bid="([^" ]+)"/g)].map((m) => m[1]);
  assert.equal(ids.length, new Set(ids).size, `Duplicate element ids: ${context}`);
  for (const match of html.matchAll(/\bfor="([^" ]+)"/g))
    assert.ok(ids.includes(match[1]), `Unbound label ${match[1]}: ${context}`);
}
let count = 0;
for (const page of allPages) {
  const html = renderToString(wrap(<PageRouter route={page.id} />, '/' + page.id));
  assert.ok(!html.includes('Sayfa bulunamadı'), page.id);
  assert.ok(html.length > 200, page.id);
  checkMarkup(html, page.id);
  assert.ok(!/href="#(?:admin|super|panel|takvim)/.test(html), page.id);
  assert.ok(!/NaN/.test(html), page.id);
  count++;
}
for (const path of ['admin/students/past', 'admin/students/1088', 'admin/students/register']) {
  const html = renderToString(wrap(<PageRouter route={path} />, '/' + path));
  assert.ok(!html.includes('Sayfa bulunamadı'), path);
  if (path.endsWith('/past')) {
    assert.match(
      html,
      /aria-current="page"[^>]*href="\/admin\/students\/past"|href="\/admin\/students\/past"[^>]*aria-current="page"/,
    );
    assert.ok(html.includes('Geçmiş öğrenciler'));
  }
  if (path.endsWith('/1088')) assert.ok(html.includes('Görüşme geçmişi'));
}
const shell = renderToString(wrap(<App />));
assert.ok(shell.includes('sidebar-container'));
assert.ok(shell.includes('Hızlı arama'));
assert.ok(shell.includes('JamAI'));
function MeetingCheck() {
  const { state } = useWorkspace();
  const student = { ...state.students[0], payment: 'Bekliyor', amount: 1234 };
  const balance = replyFor('Tahsilatları göster', {
    ...state,
    sales: undefined,
    receipts: undefined,
    students: [student],
  });
  assert.ok(balance.includes('1 öğrenci') && balance.includes('1.234'));
  assert.equal(
    replyFor('Tahsilatları göster', {
      ...state,
      sales: undefined,
      receipts: undefined,
      students: [{ ...student, payment: 'Ödendi' }],
    }),
    'Ödeme bekleyen öğrenci kaydı bulunmuyor.',
  );
  return <MeetingDialog student={student} />;
}
const meeting = renderToString(wrap(<MeetingCheck />));
assert.equal((meeting.match(/role="tabpanel"/g) || []).length, 2);
assert.match(meeting, /id="meeting-dialog-select-1"/);
assert.match(meeting, /aria-describedby="meeting-note-count"/);
assert.ok(meeting.includes('Henüz görüşme kaydı bulunmuyor.'));
console.log(
  `${count} navigation targets, application shell and meeting composition rendered successfully; JamAI balances verified.`,
);

const registration = registrationSchema.parse({
  ...emptyRegistration,
  name: 'Deniz Kaya',
  email: 'deniz@example.com',
  phone: '05321234567',
  company: 'Kurum',
  address: 'Merkez Mahallesi',
  identityNumber: 'A1234567',
  studentType: 'CORPORATE',
  dayPreference: 'CUSTOM',
  customDays: 'Salı',
  timePreference: 'CUSTOM',
  customTime: '18:30',
  meetingResult: 'NEGATIVE',
  negativeReason: 'Zaman uygun değil',
});
for (const section of [0, 1, 2]) {
  const fields = renderToString(
    <RegistrationFields
      section={section}
      draft={registration}
      patch={() => {}}
      errors={section === 0 ? { phone: 'Telefonu kontrol edin.' } : {}}
      validateField={() => {}}
    />,
  );
  checkMarkup(fields, `registration section ${section}`);
  const optionalStart = fields.indexOf('data-form-section="optional"');
  assert.ok(fields.indexOf('data-form-section="required"') < optionalStart);
  assert.ok(
    !/\brequired=""/.test(fields.slice(optionalStart)),
    `Required input inside optional registration section ${section}`,
  );
  if (section === 0) {
    assert.match(fields, /aria-invalid="true"/);
    assert.ok(fields.includes('register-phone-error'));
    assert.match(fields, /autocomplete="tel"/i);
  }
  if (section === 1) {
    assert.ok(fields.includes('register-customDays'));
    assert.ok(fields.includes('register-customTime'));
  }
  if (section === 2) {
    assert.ok(fields.includes('register-negativeReason'));
    assert.ok(fields.includes('aria-pressed="true"'));
  }
}
const review = renderToString(<RegistrationReview draft={registration} onEdit={() => {}} />);
for (const value of [
  'Merkez Mahallesi',
  'A1234567',
  'Kurum',
  '18:30',
  'Zaman uygun değil',
  'Telefon teyidi',
  'Hesap durumu',
])
  assert.ok(review.includes(value), `Missing preview value ${value}`);
assert.equal((review.match(/bölümünü düzenle/g) || []).length, 3);
const editor = renderToString(wrap(<StudentForm />));
checkMarkup(editor, 'student editor');
assert.equal((editor.match(/role="tabpanel"/g) || []).length, 1);
console.log(
  'All registration sections, inline errors, full preview and student editor labels verified.',
);

const group = groupDraft(initialOperations.groups[0]);
const teacher = { ...initialOperations.teachers[0], salary: undefined };
const expense = expenseDraft(initialOperations.expenses[0]);
const forms = [
  [
    'group',
    <GroupFields
      value={group}
      onChange={() => {}}
      teachers={initialOperations.teachers.map((t) => t.name)}
    />,
  ],
  ['teacher', <TeacherFields value={teacher} onChange={() => {}} />],
  ['expense', <ExpenseFields value={expense} onChange={() => {}} />],
] as const;
for (const [name, component] of forms) {
  const html = renderToString(<form>{component}</form>);
  checkMarkup(html, name);
  const start = html.indexOf('data-form-section="optional"');
  assert.ok(start > html.indexOf('data-form-section="required"'), name);
  assert.ok(
    !/\brequired=""/.test(html.slice(start)),
    `${name}: optional fields unexpectedly required`,
  );
}
const teacherWithoutSalary = renderToString(<TeacherFields value={teacher} onChange={() => {}} />);
assert.ok(!teacherWithoutSalary.includes('id="salary-amount"'));
const teacherWithSalary = renderToString(
  <TeacherFields
    value={{ ...teacher, salary: { amount: 100, paymentDay: 31, salaryType: 'MONTHLY' } }}
    onChange={() => {}}
  />,
);
checkMarkup(teacherWithSalary, 'teacher with salary');
assert.ok(teacherWithSalary.includes('id="salary-amount"'));
const recurrence = renderToString(
  <ExpenseFields value={{ ...expense, transactionMode: 'RECURRING' }} onChange={() => {}} />,
);
checkMarkup(recurrence, 'recurring expense');
assert.ok(recurrence.includes('id="expense-start"') && !recurrence.includes('id="expense-date"'));
for (const occupation of ['', 'STUDENT', 'EMPLOYEE', 'UNEMPLOYED'] as const) {
  const html = renderToString(
    <RegistrationFields
      section={1}
      draft={{ ...registration, occupation }}
      patch={() => {}}
      errors={{}}
      validateField={() => {}}
    />,
  );
  assert.equal(html.includes('id="register-institution"'), occupation === 'STUDENT');
  assert.equal(html.includes('id="register-company"'), occupation === 'EMPLOYEE');
}
for (const hasCampaign of [false, true]) {
  const value = { ...initialOperations.plans[0], hasCampaign };
  const required = renderToString(
    <PricingFields value={value} onChange={() => {}} section="required" />,
  );
  const optional = renderToString(
    <PricingFields value={value} onChange={() => {}} section="optional" />,
  );
  checkMarkup(required + optional, 'pricing sections');
  assert.ok(required.includes('pricing-contract') && !optional.includes('pricing-contract'));
  assert.equal(optional.includes('id="campaign-price"'), hasCampaign);
}
console.log(
  'Required/optional form hierarchy, conditional salary/campaign/recurrence fields and occupation selectors verified.',
);

// Empty collections must render without reseeding students or inventing requests.
const previousStorage = Object.getOwnPropertyDescriptor(globalThis, 'localStorage');
const emptyState = {
  students: [],
  events: [],
  meetings: [],
  attendance: {},
  attendanceSessions: [],
  moduleRows: {},
  branch: 'New York',
  privacy: false,
  chat: [],
  settings: {},
  sales: [],
  receipts: [],
};
const memoryStorage = {
  getItem(key: string) {
    return key === 'jamaster-workspace-v3'
      ? JSON.stringify(emptyState)
      : key === 'jamaster-operations-v3'
        ? JSON.stringify({
            groups: [],
            teachers: [],
            expenses: [],
            plans: [],
            messages: [],
            automations: [],
          })
        : null;
  },
  setItem() {},
  removeItem() {},
};
Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: memoryStorage });
try {
  for (const page of allPages) {
    const html = renderToString(wrap(<PageRouter route={page.id} />, '/' + page.id));
    checkMarkup(html, `empty:${page.id}`);
    assert.ok(!/NaN|undefined öğrenci/.test(html), `empty:${page.id}`);
  }
  const emptyDashboard = renderToString(wrap(<PageRouter route="admin/dashboard" />));
  assert.ok(emptyDashboard.includes('Henüz kaydedilmiş yoklama bulunmuyor.'));
  const contracts = renderToString(
    wrap(<PageRouter route="admin/contracts" />, '/admin/contracts'),
  );
  assert.ok(!contracts.includes('SÖZ-2026-104'));
  const requests = renderToString(
    wrap(<PageRouter route="admin/verification-requests" />, '/admin/verification-requests'),
  );
  assert.ok(requests.includes('Listelenecek kayıt bulunamadı.'));
} finally {
  if (previousStorage) Object.defineProperty(globalThis, 'localStorage', previousStorage);
  else delete (globalThis as { localStorage?: unknown }).localStorage;
}
for (const subpage of ['payments', 'polling-history', 'history']) {
  const path = `admin/students/1088/${subpage}`;
  const html = renderToString(wrap(<PageRouter route={path} />, '/' + path));
  assert.ok(!html.includes('Sayfa bulunamadı'), path);
  checkMarkup(html, path);
}
console.log(
  '113 routes also rendered with empty collections; student payment, polling and meeting subroutes verified.',
);

for (const [path, content] of [
  ['admin/groups/g1', 'Grup öğrencileri'],
  ['admin/teachers/t1', 'Ders programı'],
  ['admin/staff/staff-1', 'Personel bilgileri'],
] as const) {
  const html = renderToString(wrap(<PageRouter route={path} />, '/' + path));
  checkMarkup(html, path);
  assert.ok(html.includes(content), path);
  assert.ok(!html.includes('Kayıt bulunamadı'), path);
}
const settingsProfile = renderToString(wrap(<PageRouter route="user/account" />, '/user/account'));
assert.ok(settingsProfile.includes('profilePhone') && settingsProfile.includes('type="file"'));
assert.ok(!shell.includes('Sekme aralığı'));
const uploaded = { ...registration, image: 'data:image/png;base64,aGVsbG8=' };
const imageReview = renderToString(<RegistrationReview draft={uploaded} />);
assert.ok(imageReview.includes('review-profile-photo'));
assert.ok(!imageReview.includes('<dd>data:image'));
console.log(
  'Group, teacher, staff detail pages, profile inputs, removed density control and image preview verified.',
);
